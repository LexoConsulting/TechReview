package com.rbc.rbccm.yog0.ags.adapter.kafka;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConsumer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;

import com.rbc.rbccm.yog0.ags.handler.AbstractMessageHandler;
import jakarta.annotation.PreDestroy;

import jakarta.jms.ConnectionFactory;
import jakarta.jms.Message;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.listener.AcknowledgingMessageListener;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.TopicPartitionOffset;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class KafkaConsumer extends AbstractJmsConsumer {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumer.class);

    private final ConsumerFactory<String, String> consumerFactory;

    private volatile AdminClient adminClient;
    private final Object adminClientLock = new Object();

    public KafkaConsumer(String flowName, ChannelConfig channelConfig) {
        super(flowName, channelConfig);

        consumerFactory = KafkaConnectionFactoryProvider.createConsumerFactory(flowName, channelConfig);
    }

    @Override
    protected ConnectionFactory getConnectionFactory() {
        // Kafka don't use JMS ConnectionFactory
        return null;
    }

    public void startListening(AbstractMessageHandler<?, ?> messageHandler) {
        String topic = this.channelConfig.getTopic();

        String containerId = getContainerId();
        if (isListening()) {
            logger.info("Kafka listener already running for flow [{}] on topic [{}]. Skipping duplicate listener startup.", flowName, topic);
            return;
        }

        logger.info("Starting Kafka listener with headers and manual ack for flow [{}] on topic [{}] with partition [{}]", this.flowName, topic, channelConfig.getPartition());
        try {
            // Subscribe to the topic (group-managed) rather than manually assign()-ing the partition.
            // Kafka's own consumer-group rebalance protocol - combined with PinnedPartitionAssignor
            // configured on the ConsumerFactory -guarantees only oneapp replica ever owns
            // channelConfiggetPartition at a time, with automatic failover to the other replica(s)
            // if this one goes down.
            ContainerProperties containerProps = new ContainerProperties (topic);
            containerProps.setGroupId(channelConfig.getConsumerGroup());
            containerProps.setAckMode(ContainerProperties.AckMode.MANUAL);
            containerProps.setMessageListener((AcknowledgingMessageListener<String, String>) (data, acknowledgment) -> {
                onMessageReceived(messageHandler, data, acknowledgment);
            });

            ConcurrentMessageListenerContainer<String, String> container =
                    new ConcurrentMessageListenerContainer<>(consumerFactory, containerProps);
            container.setBeanName(containerId);
            container.setConcurrency(1);
            container.start();

            listenerContainers.put(containerId, container);
            logger.info("Started listener successfully for flow [{}] on topic [{}]", this.flowName, topic);

        } catch (Exception e) {
            logger.error("Failed to start Kafka listener for flow [{}] on topic [{}]: {}", this.flowName, topic, e.getMessage(), e);
            throw new RuntimeException("Failed to start Kafka listener with headers and manual ack for flow [" + flowName + "] on topic [" + topic + "]: " + e.getMessage(), e);
        }
    }
    protected boolean onMessageReceived(AbstractMessageHandler<?, ?> messageHandler, Message message) {
        // Override, Kafka has different way to handle received message
        throw new UnsupportedOperationException("KafkaConsumer does not support onMessageReceived(Message message)");
    }

    protected void onMessageReceived(AbstractMessageHandler<?, ?> messageHandler, ConsumerRecord<String, String> data, Acknowledgment acknowledgment) {
        String message = data.value();
        Map<String, String> headers = extractHeaders(data);

        boolean toAck = messageHandler.handleMessage(message, headers);
        if (toAck && acknowledgment != null ) {
            logger.info("Successful handled message, Act, headers: {}, payload: {}", headers, message);
            acknowledgment.acknowledge();
        } else {
            acknowledgment.nack(Duration.ofSeconds(this.channelConfig.getJmsServerConfig().getRetryIntervalSeconds()));
            logger.info("Failed handled message, No Act, headers: {}, payload: {}", headers, message);
        }

    }

    @PreDestroy
    public void cleanup() {
        // Clean up admin client
        if (adminClient != null) {
            try {
                logger.info("Closing Kafka admin client");
                adminClient.close();
            } catch (Exception e) {
                logger.error("Error cleaning up Kafka admin client", e);
            }
        }
    }

    public boolean isServerAvailable() {
        try {
            AdminClient adminClient = this.getOrCreateAdminClient();

            adminClient.describeCluster().nodes().get(5, TimeUnit.SECONDS);
            return true;
        } catch (Exception e) {
            logger.warn("Kafka broker health check failed: {}", e.getMessage());
            this.recreateAdminClient();
            return false;
        }
    }

    private AdminClient getOrCreateAdminClient() {
        if (adminClient == null) {
            synchronized (adminClientLock) {
                if (adminClient == null) {
                    Map<String, Object> adminProperties = new HashMap<>(consumerFactory.getConfigurationProperties());
                    adminProperties.put(AdminClientConfig.REQUEST_TIMEOUT_MS_CONFIG, 5000);
                    adminProperties.put(AdminClientConfig.DEFAULT_API_TIMEOUT_MS_CONFIG, 5000);
                    adminClient = AdminClient.create(adminProperties);
                    logger.info("Created singleton Kafka admin client for health check");
                }
            }
        }
        return adminClient;
    }

    private void recreateAdminClient() {
        synchronized (adminClientLock) {
            if (adminClient != null) {
                try {
                    adminClient.close();
                    logger.debug("Closed existing Kafka admin client");
                } catch (Exception e) {
                    logger.warn("Failed to close existing Kafka admin client: {}", e.getMessage());
                }
            }
            adminClient = null;
        }
    }

}
