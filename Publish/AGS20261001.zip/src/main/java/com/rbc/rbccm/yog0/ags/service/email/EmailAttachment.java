package com.rbc.rbccm.yog0.ags.service.email;

// Currently not used in AGS Email logic but is part of the generic Email class
public class EmailAttachment {
    private String fileName;
    private byte[] content;
    private String contentType;

    public EmailAttachment() {}

    public EmailAttachment(String fileName, byte[] content, String contentType) {
        this.fileName = fileName;
        this.content = content;
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getContent() {
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
