package com.rbc.rbccm.yog0.ags.adapter;

import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.model.exception.MessageHandlingException;
import com.rbc.rbccm.yog0.ags.model.exception.MessageSendException;
import com.rbc.rbccm.yog0.ags.handler.AbstractMessageHandler;
import jakarta.jms.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.jms.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public abstract class AbstractJmsConsumer {
    private static final Logger logger = LoggerFactory.getLogger(AbstractJmsConsumer.class);

    protected final String flowName;
    protected final ChannelConfig channelConfig;

    protected final Map<String, Object> listenerContainers = new ConcurrentHashMap<>();

    public AbstractJmsConsumer(String flowName, ChannelConfig channelConfig) {
        this.flowName = flowName;
        this.channelConfig = channelConfig;
    }

    abstract public void startListening(AbstractMessageHandler<?, ?> messageHandler);
    protected boolean onMessageReceived(AbstractMessageHandler<?, ?> messageHandler, Message message) {
        try {
            Map<String, String> headers = extractHeaders(message);

            boolean toAck = false;
            String payloadString = "";
            if (message instanceof BytesMessage bytesMessage) {
                byte[] payload = readBytesMessage(bytesMessage);
                payloadString = new String(payload, StandardCharsets.UTF_8);
                toAck = messageHandler.handleMessage(payload, headers);
            } else if (message instanceof TextMessage textMessage) {
                String payload = textMessage.getText();
                payloadString = payload;
                toAck = messageHandler.handleMessage(payload, headers);
            } else {
                logger.warn("Received unsupported JMS message type: {}", message.getClass().getName());
            }

            if (toAck) {
                logger.info("Successful handled message, Act, headers: {}, payload: {}", headers, payloadString);
            } else {
                logger.info("Failed handled message, No Act, headers: {}, payload: {}", headers, payloadString);
            }
            return toAck;
        } catch (Exception e) {
            logger.error("Failed to process JMS message: {}", e.getMessage(), e);
            throw new MessageSendException("Failed to process JMS message", e);
        }
    }

    protected abstract ConnectionFactory getConnectionFactory();
    public boolean isServerAvailable() {
        try (Connection connection = this.getConnectionFactory().createConnection()) {
            connection.start();

            // Close it immediately
            connection.close();
            return true;
        } catch (Exception e) {
            logger.warn("HealthCheck for {}: isServerAvailable: false: " + this.getClass().getSimpleName() + " failed to connect: {}", flowName, e.getMessage(), e);
            return false;
        }
    }

    protected Map<String, String> extractHeaders(Object message) {
        Map<String, String> headers = new HashMap<>();

        // How to get headers from message?
        try {
            if (message instanceof jakarta.jms.Message) {
                Message jmsMessage = (Message)message;
                if (jmsMessage.getJMSMessageID() != null) {
                    headers.put("messageID", jmsMessage.getJMSMessageID());
                }
                if (jmsMessage.getJMSCorrelationID() != null) {
                    headers.put("correlationID", jmsMessage.getJMSCorrelationID());
                }
            } else if(message instanceof ConsumerRecord) {
                ConsumerRecord<String, String> record = (ConsumerRecord<String, String>) message;
                if (record.headers() != null) {
                    record.headers().forEach(header -> {
                        String key = header.key();
                        String value = new String(header.value(), StandardCharsets.UTF_8);
                        headers.put(key, value);
                    });
                }
            }
        } catch (JMSException e) {
            logger.warn("Failed to extract headers from message, ignore it: {}", e.getMessage(), e);
        }

        // Add headers to MDC
        String corrId = headers.get("correlationId") == null? "": headers.get("correlationId");
        MDC.put("corrId", String.format("%s", corrId));

        return headers;
    }
    protected byte[] readBytesMessage(BytesMessage bytesMessage) throws Exception {
        long bodyLength = bytesMessage.getBodyLength();
        byte[] payload = new byte[(int) bodyLength];
        bytesMessage.readBytes(payload);
        return payload;
    }

    public void stopListening() {
        String containerId = getContainerId();

        Object container = listenerContainers.remove(containerId);
        if (container != null) {
            if (container instanceof ConcurrentMessageListenerContainer) {
                ((ConcurrentMessageListenerContainer<String, String>)container).stop();
            } else {
                ((AbstractMessageListenerContainer)container).stop();
            }
            logger.info("Listener stopped for flow [{}]", flowName);
        } else {
            logger.warn("No active listener found for flow [{}]", flowName);
        }
    }

    public boolean isListening() {
        String containerId = getContainerId();
        Object container = listenerContainers.get(containerId);
        if (container == null) {
            return false;
        } else {
            if (container instanceof ConcurrentMessageListenerContainer) {
                ConcurrentMessageListenerContainer kafkaContainer = ((ConcurrentMessageListenerContainer<String, String>)container);
                return kafkaContainer.isRunning();
            } else {
                AbstractMessageListenerContainer jmsContainer = ((AbstractMessageListenerContainer)container);
                return jmsContainer.isRunning();
            }
        }
    }

    protected String getContainerId() {
        String destination = StringUtils.isNotEmpty(this.channelConfig.getQueue()) ? this.channelConfig.getQueue(): this.channelConfig.getTopic();

        return this.flowName + "-" + destination;
    }


}
