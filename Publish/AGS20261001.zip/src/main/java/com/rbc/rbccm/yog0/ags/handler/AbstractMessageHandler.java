package com.rbc.rbccm.yog0.ags.handler;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.model.exception.*;
import com.rbc.rbccm.yog0.ags.model.MessageHandlingState;
import com.rbc.rbccm.yog0.ags.model.enums.FlowType;
import com.rbc.rbccm.yog0.ags.model.enums.MessageHandlingEvent;
import com.rbc.rbccm.yog0.ags.scheduler.FlowProcessor;
import com.rbc.rbccm.yog0.ags.service.CacheMessageService;
import com.rbc.rbccm.yog0.ags.service.email.RtbSupportEmailService;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.JacksonException;

import javax.swing.*;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @param <S> Source Request Class
 * @param <D> Destination Request Class
 */
public abstract class AbstractMessageHandler<S, D> {
    private static final Logger logger = LoggerFactory.getLogger(AbstractMessageHandler.class);

    protected String flowName;

    protected ChannelConfig sourceChannelConfig;
    protected ChannelConfig destChannelConfig;
    protected FlowProcessor flowProcessor;

    protected AbstractJmsProducer destChannelProducer;

    private final RtbSupportEmailService rtbSupportEmailService;
    private final CacheMessageService cacheMessageService;

    public AbstractMessageHandler() {
        this.rtbSupportEmailService = SpringContextUtil.getBean(RtbSupportEmailService.class);

        // cacheMessageService is crated manually, need to be autowired
        this.cacheMessageService = new CacheMessageService();
        SpringContextUtil.autowireBean(this.cacheMessageService);
    }

    public void init(String flowName, String storagePath, ChannelConfig sourceChannelConfig, ChannelConfig destChannelConfig, AbstractJmsProducer destChannelProducer, FlowProcessor flowProcessor) {
        this.flowName = flowName;
        this.sourceChannelConfig = sourceChannelConfig;
        this.destChannelConfig = destChannelConfig;
        this.flowProcessor = flowProcessor;
        this.destChannelProducer = destChannelProducer;

        this.cacheMessageService.init(this.flowName, storagePath);
    }

    public Map<String, String> findAndRemoveMessageHeaders(String messageKey) {
        MessageHandlingState state = this.cacheMessageService.findAndRemoveMessage(messageKey);
        if (state != null) {
            return state.getHeaders();
        }
        return null;
    }

    public void shutdown() {
        logger.info("Shutting down message handler for flow: {}, save cached messages to disk", this.flowName);
        this.cacheMessageService.saveToDisk();
    }

    /**
     * Handle the
     * @return true, the message is processed completed (Successful or Unrecoverable failed ), the listener will acknowledge it
     * @return false, the message is not processed completed with Recoverable failed, the listener will not acknowledge it
     */
    public boolean handleMessage(Object message, Map<String, String> headers) {
        String messageKey = "";
        boolean retryMessage = false;
        boolean handled = false;
        try {
            // 0: Pre process message
            this.preProcessMessage(headers);

            // 1: Populate AccountingEntryRequest -> JsonUtil
            S request = this.populateRequest(message);
            logger.debug("Message populated for flow: {}, headers: {}, request: {}", this.flowName, headers, request);

            // 2: Build message key, and also retrieve the headers from cache
            messageKey = this.buildMessageKey(request, headers);
            logger.info("Handling message for flow: {}, message key={}", this.flowName, messageKey);

            if (FlowType.INBOUND.equals(this.flowProcessor.getFlowConfig().getFlowType())) {
                // 3.1: For Inbound message, keep the headers, also check if the message is retry message
                retryMessage = this.cacheMessageService.putMessageHeaders(messageKey, headers);
            } else {
                // 3.2: For Outbound message, retrieve related request headers
                this.retrieveMessageHeaders(messageKey, headers);
            }

            // 4: Transform AccountingEntryRequest -> O_Irisreq
            D destRequest = this.transformRequest(request);

            // 5: Send to destination channel
            sendToDestinationChannel(destRequest, messageKey, headers);

            // 6: If retry success, log and notify RTB as INFO
            handleSuccess(headers, messageKey, message, retryMessage);
            handled = true;
        } catch(CantRetrieveHeadersException e) {
            // MQ Dispatch message in turn. So if the message is not able to retrieve the headers, it will be sent to the next POD
            if (retryMessage) {
                // MQ Dispatch message in turn. So if the message is not able to retrieve the headers, it will be sent to the next instance
                logger.error("Retry Message, still not able to retrieve the related request headers for messageKey: {}. Should not happens. return true to Ack it. Logged as Error", messageKey, e);
                handled = true;
            } else {
                logger.warn("New RIMMS Resp Message, not able to retrieve the related request headers for messageKey: {}. Not Act it, let MQ to send the message to next instance", messageKey);
            }
        } catch(MessageSendException re) { // Recoverable Exception
            handleRecoverableException(headers, messageKey, message, retryMessage, re);
        } catch(JacksonException | MessageValidationException | MessageHandlingException | MessageTransformationException ure) { // Uncoverable Exception
            handleUnrecoverableException(headers, messageKey, message, retryMessage, ure);
            handled = true;
        } catch (Exception ure) { // Unknown error -> default behaviour URE
            handleUnrecoverableException(headers, messageKey, message, retryMessage, ure);
            handled = true;
        }
        return handled;
    }
    protected void preProcessMessage(Map<String, String> headers) {

        // Check if the message matches the filter
        Map<String, String> filters = this.sourceChannelConfig.getFilterByHeaders();
        if (filters == null || filters.isEmpty()) {
            return;
        }
        for(String filterHeader: filters.keySet()) {
            String filterValue = filters.get(filterHeader);
            if (!filterValue.equals(headers.get(filterHeader))) {
                logger.warn("Message does not match with this flow [header: {}, value: {}], don't process it: ", filterHeader, headers.get(filterHeader));
                throw new MessageHandlingException("Message does not match with this flow");
            }
        }
    }

    protected abstract S populateRequest(Object message) throws JacksonException;

    /**
     * Build the message key based on the request and headers, and also retrive the headers from cache
     */
    protected abstract String buildMessageKey(S request, Map<String, String> headers);

    protected void retrieveMessageHeaders(String messageKey, Map<String, String> headers) {
        // Do nothing
    }

    protected abstract D transformRequest(S request);

    protected abstract void sendToDestinationChannel(D destRequest, String messageKey, Map<String, String> headers);


    protected void handleSuccess(Map<String, String> headers, String messageKey, Object message, boolean retryMessage) {
        MessageHandlingEvent event = retryMessage ? MessageHandlingEvent.RECOVERED : MessageHandlingEvent.NORMAL_SUCCESS;

        if (event == MessageHandlingEvent.RECOVERED) {
            logger.info("Message handled successful, it is retry message: messageKey={}", messageKey);

            notifyRtbMessageRecoverSuccess(this.flowName, message, headers);
        } else {
            logger.info("Message handled successful, it is new message: messageKey={}", messageKey);
        }
    }

    protected void handleRecoverableException(Map<String, String> headers, String messageKey, Object message, boolean retryMessage, Exception e) {
        MessageHandlingEvent event = retryMessage ? MessageHandlingEvent.RETRY_FAILURE : MessageHandlingEvent.FIRST_FAILURE;

        if (event == MessageHandlingEvent.FIRST_FAILURE) {
            logger.error("Failed to handle message, Recoverable, First time, will retry later. messageKey={}", messageKey, e);

            notifyRtbMessageHandledError(this.flowName, message, headers, e);
        } else {
            logger.warn("Failed to handle message, Recoverable, Retry Failed, will retry later. messageKey={}", messageKey, e);
        }
    }

    protected void handleUnrecoverableException(Map<String, String> headers, String messageKey, Object message, boolean retryMessage, Exception e) {
        logger.error("Failed to handle message, Unrecoverable, messageKey={}", messageKey, e);

        notifyRtbMessageHandledError(this.flowName, message, headers, e);
    }

    private void notifyRtbMessageHandledError(String flowName, Object message, Map<String, String> headers, Exception exception) {
        Map<String, Object> data = buildEmailData(flowName, message, headers, exception);
        rtbSupportEmailService.sendMessageHandledError(data);
    }

    private void notifyRtbMessageRecoverSuccess(String flowName, Object message, Map<String, String> headers) {
        Map<String, Object> data = buildEmailData(flowName, message, headers, null);
        rtbSupportEmailService.sendMessageRecoverSuccess(data);
    }

    private Map<String, Object> buildEmailData(String flowName, Object message, Map<String, String> headers, Exception e) {
        Map<String, Object> data = new HashMap<>();

        data.put("flowName", flowName);

        String messageStr = message instanceof byte[]? new String((byte[]) message) : (String)message;
        data.put("message", messageStr);

        if (e != null) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            data.put("exceptionMessage", e.getMessage());
            data.put("exceptionCallstack", sw.toString());
        }

        for(String key: headers.keySet()) {
            data.put(key, headers.get(key));
        }
        return data;
    }

    @Override
    public String toString() {
        return "AbstractMessageHandler{" +
                "flowName='" + flowName + '\'' +
                ", sourceChannelConfig=" + sourceChannelConfig +
                ", destChannelConfig=" + destChannelConfig +
                ", destChannelProducer=" + destChannelProducer +
                '}';
    }

    public String getFlowName() {
        return flowName;
    }

    public int getNumberOfMessageInCache() {
        return cacheMessageService.getNumberOfMessageInCache();
    }
    public String getMessageKeysInCache() {
        return cacheMessageService.getMessageKeysInCache();
    }

}
