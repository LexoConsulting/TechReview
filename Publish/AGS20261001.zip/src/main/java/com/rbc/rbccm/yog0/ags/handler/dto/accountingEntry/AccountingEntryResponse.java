package com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry;


public record AccountingEntryResponse(
        String pathwaySystemCode,
        String sourceSystemCode,
        String sid,
        String ac,
        String detailSid,
        String msgCode,
        String msgText
) {
}
