package com.rbc.rbccm.yog0.ags.service.email;

import freemarker.template.Configuration;
import freemarker.template.Template;
import io.micrometer.common.util.StringUtils;
import jakarta.annotation.PostConstruct;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@ConfigurationProperties(prefix = "ags-app.email")
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
    private final JavaMailSender javaMailSender;
    private final Configuration freemarkerConfig;

    // Generic email defaults. SMPT/server config remains under spring.mail
    private boolean enabled;
    private String from;
    private String tos;
    protected List<String> toList = new ArrayList<>();
    private String ccs;
    protected List<String> ccList = new ArrayList<>();
    private String bccs;
    protected List<String> bccList = new ArrayList<>();

    @PostConstruct
    public void init() {
        if (StringUtils.isNotEmpty(this.tos)) {
            this.toList = Arrays.stream(this.tos.split(", *")).map(String::trim).collect(Collectors.toList());
        }
        if (StringUtils.isNotEmpty(this.ccs)) {
            this.ccList = Arrays.stream(this.ccs.split(", *")).map(String::trim).collect(Collectors.toList());
        }
        if (StringUtils.isNotEmpty(this.bccs)) {
            this.bccList = Arrays.stream(this.bccs.split(", *")).map(String::trim).collect(Collectors.toList());
        }
    }

    @Autowired
    public EmailService(JavaMailSender javaMailSender, Configuration freemarkerConfig) {
        this.javaMailSender = javaMailSender;
        this.freemarkerConfig = freemarkerConfig;
    }

    public void send(Email email, Map<String, Object> data) {
        if (!enabled) {
            logger.info("Email service is disabled. Skipping email send. subject={}", email != null ? email.getSubject() : null);
            return;
        }

        try {
            String mailFrom = email.getFrom() != null ? email.getFrom() : from;
            List<String> mailTos = email.getTos() != null ? email.getTos() : this.toList;
            List<String> mailCcs = email.getCcs() != null ? email.getCcs() : this.ccList;
            List<String> mailBccs = email.getBccs() != null ? email.getBccs() : this.bccList;

            String subject = renderSubject(email, data);
            String content = renderContent(email, data);

            boolean hasAttachments = email.getAttachments() != null && !email.getAttachments().isEmpty();

            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, hasAttachments);

            helper.setFrom(mailFrom);
            helper.setTo(mailTos.toArray(new String[0]));
            helper.setSubject(subject);
            helper.setText(content, false);

            if (mailCcs != null && !mailCcs.isEmpty()) {
                helper.setCc(mailCcs.toArray(new String[0]));
            }

            if (mailBccs != null && !mailBccs.isEmpty()) {
                helper.setBcc(mailBccs.toArray(new String[0]));
            }

            if (hasAttachments) {
                addAttachments(helper, email.getAttachments());
            }

            javaMailSender.send(message);

            logger.info("Email sent successfully. subject={}, tos={}", subject, mailTos);
        } catch (Exception e) {
            logger.error("Failed to send email. exceptionClass={}, exceptionMessage={}",
                    e.getClass().getSimpleName(), e.getMessage(), e
            );

            throw new IllegalStateException("Failed to send email", e);
        }
    }

    private String renderSubject(Email email, Map<String, Object> data) throws Exception {
        if (email.getSubjectTemplate() != null) {
            String subject = renderInlineTemplate(email.getSubjectTemplate(), data);
            email.setSubject(subject);
            return subject;
        }

        return email.getSubject();
    }

    private String renderContent(Email email, Map<String, Object> data) throws Exception {
        if (email.getContentTemplate() != null) {
            Template template = freemarkerConfig.getTemplate(email.getContentTemplate());
            String content = renderTemplate(template, data);
            email.setContent(content);
            return content;
        }

        return email.getContent();
    }

    private String renderInlineTemplate(String templateText, Map<String, Object> data) throws Exception {
        Template template = new Template("inline-email-template", new StringReader(templateText), freemarkerConfig);
        return renderTemplate(template, data);
    }

    private String renderTemplate(Template template, Map<String, Object> data) throws Exception {
        StringWriter writer = new StringWriter();
        template.process(data != null ? data : Collections.emptyMap(), writer);
        return writer.toString();
    }

    private void addAttachments(MimeMessageHelper helper, List<EmailAttachment> attachments) throws Exception {
        for (EmailAttachment attachment : attachments) {
            helper.addAttachment(attachment.getFileName(), new ByteArrayResource(attachment.getContent()), attachment.getContentType());
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTos() {
        return tos;
    }

    public void setTos(String tos) {
        this.tos = tos;
    }

    public String getCcs() {
        return ccs;
    }

    public void setCcs(String ccs) {
        this.ccs = ccs;
    }

    public String getBccs() {
        return bccs;
    }

    public void setBccs(String bccs) {
        this.bccs = bccs;
    }
}
