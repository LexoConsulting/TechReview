package com.rbc.rbccm.yog0.ags.transformer;

/**
 * Defines the contract that all message transformers must implement
 */
public interface MessageTransformer<I, O> {
    /**
     * Transforms the message
     * @param message the message to transform
     * @return the transformed message
     */
    O transform(I message);
}
