package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class IrisreqDetail {
    public String book_date_yyyy;
    public String book_date_mm;
    public String book_date_dd;
    public String iris_dtl_sid;
    public String cr_dr_id;
    public String nbr;
    public String typ;
    public String ccy;
    public String ref;
    public String sbr;
    public String amt;
    public String sid_text;
    public String vat;
    public String fac;
    public String filler0;
}
