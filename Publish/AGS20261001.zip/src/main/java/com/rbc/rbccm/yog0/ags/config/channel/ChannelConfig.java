package com.rbc.rbccm.yog0.ags.config.channel;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public class ChannelConfig {
    private String jmsServer;
    private JmsServerConfig jmsServerConfig;

    // Filter by headers, optional
    private Map<String, String> filterByHeaders = new HashMap<>();

    // Kafka used topic, IBMMQ/ActiveMQ used queue, Solace used both queue and topic
    private String queue;
    private String topic;

    // Only For Kafka
    private int partition = 0;
    private String consumerGroup;
    private Map<String, Integer> producerPartitions = new HashMap<>();

    public String getDestination() {
        return StringUtils.isNotEmpty(queue)? this.queue: this.topic;
    }

    public ChannelConfig() {
    }

    public String getJmsServer() {
        return jmsServer;
    }

    public void setJmsServer(String jmsServer) {
        this.jmsServer = jmsServer;
    }

    public JmsServerConfig getJmsServerConfig() {
        return jmsServerConfig;
    }

    public void setJmsServerConfig(JmsServerConfig jmsServerConfig) {
        this.jmsServerConfig = jmsServerConfig;
    }

    public Map<String, String> getFilterByHeaders() {
        return filterByHeaders;
    }

    public void setFilterByHeaders(Map<String, String> filterByHeaders) {
        this.filterByHeaders = filterByHeaders;
    }

    public String getQueue() {
        return queue;
    }

    public void setQueue(String queue) {
        this.queue = queue;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getPartition() {
        return partition;
    }

    public void setPartition(int partition) {
        this.partition = partition;
    }

    public String getConsumerGroup() {
        return consumerGroup;
    }

    public void setConsumerGroup(String consumerGroup) {
        this.consumerGroup = consumerGroup;
    }

    public Map<String, Integer> getProducerPartitions() {
        return producerPartitions;
    }

    public void setProducerPartitions(Map<String, Integer> producerPartitions) {
        this.producerPartitions = producerPartitions;
    }
}
