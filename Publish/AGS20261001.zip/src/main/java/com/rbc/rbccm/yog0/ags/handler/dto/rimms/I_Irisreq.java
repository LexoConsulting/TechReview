package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

import com.rbc.rbccm.yog0.ags.model.exception.MessageTransformationException;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class I_Irisreq {
    protected int _bufferLen = 154;
    public I_IrisreqSummary summary = new I_IrisreqSummary();
    public List<I_IrisreqDetail> details = new ArrayList<>();

    public void unmarshal(byte[] _buffer, int _count) {
        String payload = new String(_buffer, 0, _count, StandardCharsets.UTF_8);

        List<String> nonEmptyLines = Arrays.stream(payload.split("\\R"))
            .filter(line -> !line.trim().isEmpty())
            .toList();

        if (nonEmptyLines.isEmpty()) {
            throw new MessageTransformationException("Failed to unmarshal Irisreq payload: payload is empty or contains only blank lines.");
        }

        this.summary = new I_IrisreqSummary();
        this.details = new ArrayList<>();

        ((I_IrisreqSummary) this.summary).unmarshal(nonEmptyLines.get(0));

        for (int i = 1; i < nonEmptyLines.size(); i++) {
            I_IrisreqDetail detail = new I_IrisreqDetail();
            detail.unmarshal(nonEmptyLines.get(i));
            this.details.add(detail);
        }
    }
}
