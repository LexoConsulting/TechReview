package com.rbc.rbccm.yog0.ags.model;

import java.math.BigDecimal;

public record AccountingEntrySummary(
        String sourceSystemCode,
        String sid,
        String year,
        String month,
        String day,
        String hour,
        String minute,
        String second,
        Integer creditCount,
        Integer debitCount,
        BigDecimal creditAmount,
        BigDecimal debitAmount,
        String description,
        String reversal
) {
}
