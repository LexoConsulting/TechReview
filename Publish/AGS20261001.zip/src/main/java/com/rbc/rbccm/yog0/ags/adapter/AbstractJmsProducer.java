package com.rbc.rbccm.yog0.ags.adapter;

import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;

import java.util.Map;

public abstract class AbstractJmsProducer {
    protected final String flowName;
    protected final ChannelConfig channelConfig;

    public AbstractJmsProducer(String flowName, ChannelConfig channelConfig) {
        this.flowName = flowName;
        this.channelConfig = channelConfig;
    }

    abstract public void send(String messageKey, Object message, Integer partition, Map<String, String> headers);

    public String getFlowName() {
        return flowName;
    }

    public ChannelConfig getChannelConfig() {
        return channelConfig;
    }
}
