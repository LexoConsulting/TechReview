package com.rbc.rbccm.yog0.ags.adapter.kafka;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.model.exception.MessageSendException;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.Map;
import java.util.concurrent.TimeUnit;

public class KafkaProducer extends AbstractJmsProducer {
    private static final Logger logger = LoggerFactory.getLogger(KafkaProducer.class);

    private final KafkaTemplate<String, String> kafkaTemplate;

    public KafkaProducer(String flowName, ChannelConfig channelConfig) {
        super(flowName, channelConfig);

        ProducerFactory<String, String> producerFactory = KafkaConnectionFactoryProvider.createProducerFactory(flowName, channelConfig);
        this.kafkaTemplate = new KafkaTemplate<>(producerFactory);
    }

    public void send(String messageKey, Object messageParam, Integer partition, Map<String, String> headers) {
        String topic = this.channelConfig.getTopic();
        String message = String.valueOf(messageParam);

        logger.info("Sending message to Kafka topic|partition [{}|{}], messageKey: {}", topic, partition, messageKey);
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, partition, null, message);

        // Add headers to the record
        if (headers != null && !headers.isEmpty()) {
            headers.forEach((key, value) -> {
                if (value != null) {
                    record.headers().add(key, value.getBytes());
                }
            });
        }

        sendRecord(record, topic, partition);
    }

    private void sendRecord(ProducerRecord<String, String> record, String topic, Integer partition) {
        try {
            kafkaTemplate.send(record).get(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new MessageSendException("Interrupted while sending message to Kafka topic: " + topic + ", partition: " + partition, e);
        } catch (Exception e) {
            throw new MessageSendException("Failed to send message to Kafka topic: " + topic + ", partition: " + partition, e);
        }
    }
}

