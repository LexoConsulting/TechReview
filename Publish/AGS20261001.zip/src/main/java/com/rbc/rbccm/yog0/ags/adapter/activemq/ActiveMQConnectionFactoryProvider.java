package com.rbc.rbccm.yog0.ags.adapter.activemq;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConnectionFactory;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.config.channel.JmsServerConfig;
import jakarta.jms.ConnectionFactory;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class ActiveMQConnectionFactoryProvider extends AbstractJmsConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(ActiveMQConnectionFactoryProvider.class);

    private final static Map<String, ConnectionFactory> connectionFactories = new HashMap<>();

    public static ConnectionFactory getConnectionFactory(String flowName, ChannelConfig config) {
        return connectionFactories.computeIfAbsent(flowName, key -> createConnectionFactory(key, config));
    }

    private static ConnectionFactory createConnectionFactory(String flowName, ChannelConfig config) {
        JmsServerConfig jmsServerConfig = config.getJmsServerConfig();
        String brokerUrl = jmsServerConfig.getServers();
        logger.info("Creating ActiveMQ ConnectionFactory for flow [{}] with broker URL: {}", flowName, brokerUrl);
        
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerUrl);
        connectionFactory.setTrustAllPackages(true);

        if (jmsServerConfig.getClientUsername() != null) {
            connectionFactory.setUserName(jmsServerConfig.getClientUsername());
        }
        if (jmsServerConfig.getClientPassword() != null) {
            connectionFactory.setPassword(jmsServerConfig.getClientPassword());
        }

        // Configure redelivery policy to delay redelivery by 60 seconds on rollback
        RedeliveryPolicy redeliveryPolicy = new RedeliveryPolicy();
        redeliveryPolicy.setInitialRedeliveryDelay(60000); // 60 seconds
        redeliveryPolicy.setRedeliveryDelay(60000); // 60 seconds for subsequent redeliveries
        redeliveryPolicy.setMaximumRedeliveries(-1); // Unlimited redeliveries
        redeliveryPolicy.setBackOffMultiplier(1.0); // No exponential backoff
        connectionFactory.setRedeliveryPolicy(redeliveryPolicy);

        logger.info("ActiveMQ redelivery policy configured with 60 second delay for flow [{}]", flowName);

        return connectionFactory;
    }

}
