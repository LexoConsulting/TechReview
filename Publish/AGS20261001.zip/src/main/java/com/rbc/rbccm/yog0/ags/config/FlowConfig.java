package com.rbc.rbccm.yog0.ags.config;

import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.model.enums.FlowType;
import org.apache.commons.lang3.ArrayUtils;

public class FlowConfig {
    private boolean enabled;
    private FlowType flowType;
    private String[] relatedInboundFlows;

    private String messageHandlerClass;

    private ChannelConfig sourceChannel;
    private ChannelConfig destinationChannel;

    private String transformerClass;

    public FlowConfig() {
    }

    @Override
    public String toString() {
        return "FlowConfig{" +
                "enabled=" + enabled +
                ", flowType=" + flowType +
                ", relatedInboundFlows=" + ArrayUtils.toString(relatedInboundFlows) +
                ", messageHandlerClass=" + messageHandlerClass +
                ", sourceChannel=" + sourceChannel +
                ", destinationChannel=" + destinationChannel +
                ", transformerClass='" + transformerClass + '\'' +
                '}';
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public FlowType getFlowType() {
        return flowType;
    }

    public void setFlowType(FlowType flowType) {
        this.flowType = flowType;
    }

    public String[] getRelatedInboundFlows() {
        return relatedInboundFlows;
    }

    public void setRelatedInboundFlows(String[] relatedInboundFlows) {
        this.relatedInboundFlows = relatedInboundFlows;
    }

    public String getMessageHandlerClass() {
        return messageHandlerClass;
    }

    public void setMessageHandlerClass(String messageHandlerClass) {
        this.messageHandlerClass = messageHandlerClass;
    }

    public ChannelConfig getSourceChannel() {
        return sourceChannel;
    }

    public void setSourceChannel(ChannelConfig sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public ChannelConfig getDestinationChannel() {
        return destinationChannel;
    }

    public void setDestinationChannel(ChannelConfig destinationChannel) {
        this.destinationChannel = destinationChannel;
    }

    public String getTransformerClass() {
        return transformerClass;
    }

    public void setTransformerClass(String transformerClass) {
        this.transformerClass = transformerClass;
    }
}
