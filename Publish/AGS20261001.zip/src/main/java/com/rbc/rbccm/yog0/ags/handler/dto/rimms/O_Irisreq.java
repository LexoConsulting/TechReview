package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class O_Irisreq {
    protected int _bufferLen = 154;
    public O_IrisreqSummary summary = new O_IrisreqSummary();
    public List<O_IrisreqDetail> details = new ArrayList<>();

    public byte[] marshal() {
        List<String> lines = new ArrayList<>();

        if (summary == null) {
            throw new IllegalStateException("Cannot marshal Irisreq: summary is missing");
        }

        lines.add(summary.marshal());

        if (details != null) {
            for (IrisreqDetail detail : details) {
                if (!(detail instanceof O_IrisreqDetail oDetail)) {
                    throw new IllegalStateException("Cannot marshal Irisreq: detail must be O_IrisreqDetail");
                }

                lines.add(oDetail.marshal());
            }
        }

        String payload = String.join("\n", lines);
        return payload.getBytes(StandardCharsets.UTF_8);
    }
}
