package com.rbc.rbccm.yog0.ags;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import com.ibm.mq.spring.boot.MQAutoConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jms.autoconfigure.JmsAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(exclude = {JmsAutoConfiguration.class, MQAutoConfiguration.class})
@EnableScheduling
@EnableJms
@ConfigurationPropertiesScan
public class AccountingGatewayServiceApp {
    private static final Logger logger = LoggerFactory.getLogger(AccountingGatewayServiceApp.class);
    public static void main(String[] args) {
        SpringApplication.run(AccountingGatewayServiceApp.class, args);

        String activeProfile = System.getenv("SPRING_PROFILES_ACTIVE");
        String appPodName = System.getenv("appPodName");
        String appPodIP = System.getenv("appPodIP");
        logger.info("App is started: activeProfile={}, appPodName{}, appPodIP={}", activeProfile, appPodName, appPodIP);
    }
}
