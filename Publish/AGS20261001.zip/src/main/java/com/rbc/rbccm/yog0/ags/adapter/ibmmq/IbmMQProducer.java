package com.rbc.rbccm.yog0.ags.adapter.ibmmq;

import com.ibm.mq.jakarta.jms.MQQueue;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import io.micrometer.common.util.StringUtils;
import jakarta.jms.BytesMessage;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import jakarta.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.JmsException;
import org.springframework.jms.UncategorizedJmsException;
import org.springframework.jms.core.JmsTemplate;

import java.util.Map;

public class IbmMQProducer extends AbstractJmsProducer {
    private static final Logger logger = LoggerFactory.getLogger(IbmMQProducer.class);

    private final JmsTemplate jmsTemplate;

    public IbmMQProducer(String flowName, ChannelConfig channelConfig) {
        super(flowName, channelConfig);

        ConnectionFactory connectionFactory = IbmMQConnectionFactoryProvider.getConnectionFactory(flowName, channelConfig);
        this.jmsTemplate = new JmsTemplate(connectionFactory);
    }

    @Override
    public void send(String messageKey, Object message, Integer partition, Map<String, String> headers) {
        if (message == null) {
            throw new IllegalArgumentException("Payload cannot be null");
        }

        String destination = channelConfig.getDestination();
        try {
            MQQueue mqQueue = new MQQueue(destination);

            // Make sure use MQ style, remove the RFH2 header
            mqQueue.setTargetClient(WMQConstants.WMQ_CLIENT_NONJMS_MQ);
            mqQueue.setMessageBodyStyle(WMQConstants.WMQ_MESSAGE_BODY_MQ);

            if (message instanceof byte[]) {
                byte[] payload = (byte[])message;

                jmsTemplate.send(mqQueue, session -> {
                    BytesMessage bytesMessage = session.createBytesMessage();

                    bytesMessage.writeBytes(payload);
                    return bytesMessage;
                });
                logger.info("Sent byte[] message: {} to destination: {}. Payload length: {} bytes. message: {}",
                        messageKey, destination, payload.length, new String(payload));
            } else {
                String payload = message.toString();

                // Send to destination topic as String text
                jmsTemplate.send(mqQueue, session -> {
                    TextMessage textMessage = session.createTextMessage(message.toString());
                    return textMessage;
                });

                logger.info("Sent text message to destination destination {} for flow: {}. Payload length: {} bytes",
                        destination, this.flowName, payload.length());
            }
        } catch (JMSException e) {
            logger.error("Failed to send message: errorCode: {}, errorMessage: {}", e.getErrorCode(), e.getMessage(), e);
            throw new UncategorizedJmsException(e.getMessage(), e);
        } catch(JmsException e) {
            logger.error("Failed to send message: errorCode: {}, errorMessage: {}", e.getErrorCode(), e.getMessage(), e);
            throw e;
        }

    }
}
