package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

import java.nio.charset.StandardCharsets;

public class I_Irisresp extends Irisresp {
    public void unmarshal(byte[] _buffer, int _count) {
        String content = new String(_buffer, 0, _count, StandardCharsets.UTF_8);
        String[] parts = content.split("\\|", -1);

        int i = 0;
        this.reply_pway_sys = get(parts, i++);
        this.reply_source_sys = get(parts, i++);
        this.reply_hdr_sid = get(parts, i++);
        this.reply_ac_batch_id = get(parts, i++);
        this.reply_dtl_sid = get(parts, i++);
        this.reply_msg_status = get(parts, i++);
        this.reply_msg_nbr = get(parts, i++);
        this.reply_msg_text = get(parts, i++);
        this.reply_msg_text_1 = get(parts, i);
    }

    private String get(String[] parts, int index) {
        return index < parts.length ? parts[index] : "";
    }
}
