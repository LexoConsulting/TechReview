package com.rbc.rbccm.yog0.ags.adapter.kafka;

import org.apache.kafka.clients.consumer.ConsumerPartitionAssignor;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.Configurable;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* Kafka {@Link ConsumerPartitionAssignor} that always assigns a fixed/pinned partition to exactly
 * ONE alive member of the consumer group, leaving all other members with an empty assignment.
 * This lets multiple app replicas (e.g. 2 Docker pods) run identically-configured Kafka consumers,
 * each hard-pinned (via {@Link #PINNED_PARTITION_CONFIG}) to the same partition for a given client
 * (e.g. IPAY always partition 0, RIBS always partition 1 of the same shaned topic), while Kafka's
 * own group-coordinator rebalance/heartbeat protocol guarantees:
 * - only onereplica actively consumes that partition at a time (active/primary, and
 * - on failure of the active replica (missed heartbeats/ session timeout), the partition is automatically
 *
 * reassigned to the surviving replica (standby becomes active) on the next rebalance.
 * No external coordination (DB Lock, Zookeeper; etg.) is needed - Kafka's existing consumer-group.
 * protocol is reused purely as the leader-election/failover mechanism.
 *
 * Each member advertises its pinned partition Via subscription userData
 * (set in {@link #subscriptionUserData(java.util.Set)}), which is populated from the
 * {@vaLue #PINNED_PARTITION_CONFIG consumen config property (see fallok #configure (Map)?.
 */
public class PinnedPartitionAssignor implements ConsumerPartitionAssignor, Configurable {
    private static final Logger logger = LoggerFactory.getLogger(PinnedPartitionAssignor.class);

    public static final String PINNED_PARTITION_CONFIG = "pinned.partition.assignor.partition";

    private Integer pinnedPartition;

    @Override
    public void configure(Map<String, ?> configs) {
        Object value = configs.get(PINNED_PARTITION_CONFIG);
        if (value == null) {
            throw new IllegalStateException("Missing required consumer config: " + PINNED_PARTITION_CONFIG);
        }
        this.pinnedPartition = (value instanceof Integer) ? (Integer) value : Integer.parseInt(value.toString());
    }

    @Override
    public ByteBuffer subscriptionUserData(java.util.Set<String> topics) {
        ByteBuffer buffer = ByteBuffer.allocate(Integer.BYTES);
        buffer.putInt(pinnedPartition);
        buffer.flip();
        return buffer;
    }

    @Override
    public String name() {
        return "pinned-partition";
    }

    @Override
    public GroupAssignment assign(Cluster metadata, GroupSubscription groupSubscription) {
        Map<String, Subscription> subscriptions = groupSubscription.groupSubscription();

        // Group member IDs by (topic, desired pinned partition). Using a TreeMap keeps member
        // ordering deterministic (lexicographically smallest member ID becomes the owner), so the
        // same partition consistently picks the same active member on repeated rebalances whenever
        // the previous owner is still present.
        Map<TopicPartition, List<String>> candidatesByPartition = new HashMap<>();

        for (Map.Entry<String, Subscription> entry : subscriptions.entrySet()) {
            String memberId = entry.getKey();
            Subscription subscription = entry.getValue();

            Integer desiredPartition = decodePinnedPartition(subscription.userData());
            if (desiredPartition == null || subscription.topics().isEmpty()) {
                logger.warn("Member [{}] did not advertise a pinned partition; it will receive no assignment", memberId);
                continue;
            }

            for (String topic : subscription.topics()) {
                TopicPartition topicPartition = new TopicPartition(topic, desiredPartition);
                candidatesByPartition
                        .computeIfAbsent(topicPartition, tp -> new ArrayList<>())
                        .add(memberId);
            }
        }

        Map<String, List<TopicPartition>> assignments = new HashMap<>();
        for (String memberId: subscriptions.keySet()) {
            assignments.put(memberId, new ArrayList<>());
        }

        for (Map.Entry<TopicPartition, List<String>> entry: candidatesByPartition.entrySet()) {
            TopicPartition topicPartition = entry.getKey();
            List<String> candidates = new ArrayList<>(entry.getValue());
            Collections.sort(candidates);

            String owner = candidates.get(0);
            assignments.get(owner).add(topicPartition);

            logger.info("Pinned partition {} assigned to member [{}] (candidates: {})", topicPartition, owner, candidates);
        }

        Map<String, Assignment> result = new HashMap<>();
        assignments.forEach((memberId, partitions) -> result.put(memberId, new Assignment(partitions)));
        return new GroupAssignment(result);
    }

    private Integer decodePinnedPartition(ByteBuffer userData) {
        if (userData == null || userData.remaining() < Integer.BYTES) {
            return null;
        }
        return userData.duplicate().getInt();
    }
}
