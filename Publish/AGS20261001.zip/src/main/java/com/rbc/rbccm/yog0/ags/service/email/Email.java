package com.rbc.rbccm.yog0.ags.service.email;

import java.util.List;

public class Email {
    // form, tos, ccs, bccs, subject (tobe replaced with data), content, contentTemplate file), attachments
    private String from;
    private List<String> tos;
    private List<String> ccs;
    private List<String> bccs;

    private String subject;
    private String subjectTemplate;

    private String content;
    private String contentTemplate;

    private List<EmailAttachment> attachments;

    public Email() {}

    public Email(String from, List<String> tos, List<String> ccs, List<String> bccs, String subject, String subjectTemplate, String content, String contentTemplate, List<EmailAttachment> attachments) {
        this.from = from;
        this.tos = tos;
        this.ccs = ccs;
        this.bccs = bccs;
        this.subject = subject;
        this.subjectTemplate = subjectTemplate;
        this.content = content;
        this.contentTemplate = contentTemplate;
        this.attachments = attachments;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public List<String> getTos() {
        return tos;
    }

    public void setTos(List<String> tos) {
        this.tos = tos;
    }

    public List<String> getCcs() {
        return ccs;
    }

    public void setCcs(List<String> ccs) {
        this.ccs = ccs;
    }

    public List<String> getBccs() {
        return bccs;
    }

    public void setBccs(List<String> bccs) {
        this.bccs = bccs;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubjectTemplate() {
        return subjectTemplate;
    }

    public void setSubjectTemplate(String subjectTemplate) {
        this.subjectTemplate = subjectTemplate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getContentTemplate() {
        return contentTemplate;
    }

    public void setContentTemplate(String contentTemplate) {
        this.contentTemplate = contentTemplate;
    }

    public List<EmailAttachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<EmailAttachment> attachments) {
        this.attachments = attachments;
    }
}
