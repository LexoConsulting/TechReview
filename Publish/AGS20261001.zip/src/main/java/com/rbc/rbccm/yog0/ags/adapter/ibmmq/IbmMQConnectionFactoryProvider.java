package com.rbc.rbccm.yog0.ags.adapter.ibmmq;

import com.ibm.mq.jakarta.jms.MQConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConnectionFactory;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.config.channel.JmsServerConfig;
import jakarta.jms.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class IbmMQConnectionFactoryProvider extends AbstractJmsConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(IbmMQConnectionFactoryProvider.class);

    private final static Map<String, ConnectionFactory> connectionFactories = new HashMap<>();

    public static ConnectionFactory getConnectionFactory(String flowName, ChannelConfig config) {
        return connectionFactories.computeIfAbsent(flowName, key -> createConnectionFactory(key, config));
    }

    private static ConnectionFactory createConnectionFactory(String flowName, ChannelConfig config) {
        JmsServerConfig jmsServerConfig = config.getJmsServerConfig();
        String servers = jmsServerConfig.getServers();
        String queueManager = jmsServerConfig.getQueueManager();
        String mqChannel = jmsServerConfig.getMqChannel();

        logger.info("Creating IBM MQ ConnectionFactory for flow [{}] with servers: {}, queueManager: {}, channel: {}",
                flowName, servers, queueManager, mqChannel);

        try {
            // Parse host and port from servers (format: host:port)
            String host = AbstractJmsConnectionFactory.extractHost(servers);
            int port = AbstractJmsConnectionFactory.extractPort(servers, 1414);
            logger.info("Create IBM MQ ConnectionFactory for flow: {} with. host: {}, port: {}, queueManager: {}, channel: {}",
                    flowName, host, port, queueManager, mqChannel);

            MQConnectionFactory connectionFactory = new MQConnectionFactory();

            // Set connection properties
            connectionFactory.setHostName(host);
            connectionFactory.setPort(port);
            connectionFactory.setQueueManager(queueManager);
            connectionFactory.setChannel(mqChannel);
            connectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);

            logger.info("Suppress MQ RFH2 header so non-JMS consumers (e.g. RIMMS/BWCONV) receive clean payload");
            connectionFactory.setTargetClientMatching(false);

            // Enable MQCSP authentication mode
            // This is required by some MQ configuration even for client-based auth
            // connectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true);

            // Set the Client user Id for channel authentication
            // MQ will match this against the User Map based on Client user id and connection address
            if (jmsServerConfig.getClientUsername() != null && !jmsServerConfig.getClientUsername().isBlank()) {
                connectionFactory.setStringProperty(WMQConstants.USERID, jmsServerConfig.getClientUsername());
                logger.info("Set MQ Clint User Id to: {}", jmsServerConfig.getClientUsername());

                // Note: Password is intentionly not set for client-based authentication
            } else {
                logger.warn("MQ Client User Id is not configured for flow: {}", flowName);
            }

            // Note: Redelivery delay for IBM MQ is configured server-side on the queue
            // Configure BACKOUT queue with backout threshold and retry interval on the MQ queue
            // Example MQSC commands:
            // DEFINE QLOCAL(MY_QUEUE) BACKOUTQ(MY_BACKOUT_QUEUE) BOQTHRESH(5) BOTHRESH(5)
            // DEFINE QLOCAL(MY_BACKOUT_QUEUE)
            // The retry interval is controlled by the queue's RETRYINT attribute

            logger.info("IBM MQ ConnectionFactory created successfully for flow [{}]", flowName);
            return connectionFactory;

        } catch (Exception e) {
            logger.error("Failed to create IBM MQ ConnectionFactory for flow [{}]: {}", flowName, e.getMessage(), e);
            throw new RuntimeException("Failed to create IBM MQ ConnectionFactory for flow: " + flowName, e);
        }
    }
}
