package com.rbc.rbccm.yog0.ags.transformer;

import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryRequest;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisreq;
import org.springframework.stereotype.Component;

@Component
public class AutoConvertMessageTransformer implements MessageTransformer<AccountingEntryRequest, O_Irisreq> {

    @Override
    public O_Irisreq transform(AccountingEntryRequest request) {
        return null;
    }
}
