package com.rbc.rbccm.yog0.ags.handler;

import com.fasterxml.jackson.core.JacksonException;
import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryRequest;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisreq;
import com.rbc.rbccm.yog0.ags.transformer.AccountingEntryMessageTransformer;
import com.rbc.rbccm.yog0.ags.transformer.AutoConvertMessageTransformer;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class AutoConvertRequestMessageHandler extends AccountingEntryRequestMessageHandler {
    private static final Logger logger = LoggerFactory.getLogger(AutoConvertRequestMessageHandler.class);

    private final AutoConvertMessageTransformer messageTransformer;

    public AutoConvertRequestMessageHandler() {
        this.messageTransformer = SpringContextUtil.getBean(AutoConvertMessageTransformer.class);
    }

    @Override
    protected AccountingEntryRequest populateRequest(Object message) throws JacksonException  {
        return super.populateRequest(message);
    }

    @Override
    protected String buildMessageKey(AccountingEntryRequest request, Map<String, String> headers) {
        return super.buildMessageKey(request, headers);
    }

    @Override
    protected O_Irisreq transformRequest(AccountingEntryRequest request) {
        return super.transformRequest(request);
    }

    @Override
    protected void sendToDestinationChannel(O_Irisreq destRequest, String messageKey, Map<String, String> headers) {
        super.sendToDestinationChannel(destRequest, messageKey, headers);
    }
}
