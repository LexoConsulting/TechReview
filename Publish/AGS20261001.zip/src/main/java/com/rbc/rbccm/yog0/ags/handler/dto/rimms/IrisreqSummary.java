package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class IrisreqSummary {
    public String source_sys_code;
    public String iris_hdr_sid;
    public String batch_date_yyyy;
    public String batch_date_mm;
    public String batch_date_dd;
    public String hh;
    public String batch_time_mm;
    public String ss;
    public String batch_cr_count;
    public String batch_dr_count;
    public String batch_cr_total;
    public String batch_dr_total;
    public String batch_text;
    public String reversal_ind;
    public String group_number;
    public String group_total;
    public String group_name;

    /**
     * @return the Key information
     */
    public String getKey() {
        return String.format("source_sys_code=%s, sid=%s", source_sys_code, iris_hdr_sid);
    }

}
