package com.rbc.rbccm.yog0.ags.model.enums;

public enum MessageHandlingEvent {
    NORMAL_SUCCESS,
    FIRST_FAILURE,
    RETRY_FAILURE,
    RECOVERED
}
