package com.rbc.rbccm.yog0.ags.adapter.solacemq;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConnectionFactory;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.config.channel.JmsServerConfig;
import com.solacesystems.jms.SolConnectionFactory;
import com.solacesystems.jms.SolConnectionFactoryImpl;
import jakarta.jms.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class SolaceMQConnectionFactoryProvider extends AbstractJmsConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(SolaceMQConnectionFactoryProvider.class);

    private final static Map<String, ConnectionFactory> connectionFactories = new HashMap<>();

    public static ConnectionFactory getConnectionFactory(String flowName, ChannelConfig config) {
        return connectionFactories.computeIfAbsent(flowName, key -> createConnectionFactory(key, config));
    }

    private static ConnectionFactory createConnectionFactory(String flowName, ChannelConfig config) {
        JmsServerConfig jmsServerConfig = config.getJmsServerConfig();
        String servers = jmsServerConfig.getServers();
        logger.info("Creating Solace MQ ConnectionFactory for flow [{}] with servers: {}", flowName, servers);

        try {
            SolConnectionFactory connectionFactory = new SolConnectionFactoryImpl();

            // Set connection properties
            String host = AbstractJmsConnectionFactory.extractHost(servers);
            int port = AbstractJmsConnectionFactory.extractPort(servers, 55555);
            connectionFactory.setHost(host);
            connectionFactory.setPort(port);

            // Set VPN name if available in config (you may need to add this to ChannelConfig)
            connectionFactory.setVPN(jmsServerConfig.getMsgVpn());

            // Set Username/pwd for Solace
            connectionFactory.setUsername(jmsServerConfig.getClientUsername());
            connectionFactory.setPassword(jmsServerConfig.getClientPassword());

            // Direct transport does not support transacted or XA sessions with Solace JMS.
            // Disable it so DefaultMessageListenerContainer can use the app's transacted listener pattern.
            connectionFactory.setDirectTransport(false);

            // Note: Redelivery delay for Solace MQ is configured server-side on the queue
            // Configure Dead Message Queue (DMQ) with max redelivery count and delay on the Solace queue
            // Example Solace CLI commands:
            // configure queue <queue-name> max-redeliveries 5
            // configure queue <queue-name> dead-message-queue <dmq-name>
            // The delay between redeliveries is controlled by the queue's delivery delay configuration

            logger.info("Solace MQ ConnectionFactory created successfully for flow [{}] with Username: {} and pwd", flowName, jmsServerConfig.getClientUsername());
            return connectionFactory;

        } catch (Exception e) {
            logger.error("Failed to create Solace MQ ConnectionFactory for flow [{}]: {}", flowName, e.getMessage(), e);
            throw new RuntimeException("Failed to create Solace MQ ConnectionFactory for flow: " + flowName, e);
        }
    }

}
