package com.rbc.rbccm.yog0.ags.handler;

import com.fasterxml.jackson.core.JacksonException;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryRequest;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisreq;
import com.rbc.rbccm.yog0.ags.model.exception.MessageSendException;
import com.rbc.rbccm.yog0.ags.transformer.AccountingEntryMessageTransformer;
import com.rbc.rbccm.yog0.ags.util.JsonUtil;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Map;

public class AccountingEntryRequestMessageHandler extends AbstractMessageHandler<AccountingEntryRequest, O_Irisreq> {
    private static final Logger logger = LoggerFactory.getLogger(AccountingEntryRequestMessageHandler.class);

    private final AccountingEntryMessageTransformer messageTransformer;

    public AccountingEntryRequestMessageHandler() {
        this.messageTransformer = SpringContextUtil.getBean(AccountingEntryMessageTransformer.class);
    }

    protected AccountingEntryRequest populateRequest(Object message) throws JacksonException {
        return JsonUtil.parseJson((String)message, AccountingEntryRequest.class);
    }

    protected String buildMessageKey(AccountingEntryRequest request, Map<String, String> headers) {
        // Remove leading zeros from SID
        String sid = request.summary().sid().replaceFirst("^0+(?!$)", "");
        String messageKey = String.format("%s-%s", request.summary().sourceSystemCode(), sid);

        // Add headers to MDC
        MDC.put("corrId", String.format("%s", messageKey));
        return messageKey;
    }

    protected O_Irisreq transformRequest(AccountingEntryRequest request) {
        O_Irisreq o_Irisreq = messageTransformer.transform(request);

        logger.info("AccountingEntryRequest transformed to RIMMS object");
        return o_Irisreq;
    }

    protected void sendToDestinationChannel(O_Irisreq destRequest, String messageKey, Map<String, String> headers) {
        ChannelConfig destChannelConfig = this.destChannelProducer.getChannelConfig();
        try {
            byte[] payload = destRequest.marshal();
            this.destChannelProducer.send(messageKey, payload, null, headers);

            logger.info("Successfully sent AccountingEntry message to destination. messageKey={}", messageKey);
//        } catch (DataConvertionException e) {
//            throw new MessageTransformationException("Failed to convert to RIMMS payload", e);
        } catch (Exception e) {
            throw new MessageSendException("Failed to send AccountingEntry request to topic: " + destChannelConfig.getTopic() + " for flow: " + this.destChannelProducer.getFlowName(), e);
        }
    }

}
