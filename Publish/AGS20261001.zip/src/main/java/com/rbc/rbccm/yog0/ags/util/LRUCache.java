package com.rbc.rbccm.yog0.ags.util;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

public class LRUCache<K, V> extends LinkedHashMap<K, V> implements Serializable {
    private int maxSize = 1000;

    public LRUCache(int maxSize) {
        super(maxSize, 0.75f, true);

        this.maxSize = maxSize;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
        return size() > maxSize;
    }
}
