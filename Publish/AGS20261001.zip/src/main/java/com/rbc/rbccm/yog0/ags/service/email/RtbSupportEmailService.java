package com.rbc.rbccm.yog0.ags.service.email;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class RtbSupportEmailService {

    private static final Logger logger = LoggerFactory.getLogger(RtbSupportEmailService.class);

    private final EmailService emailService;

    public static final String MESSAGE_HANDLED_ERROR_TEMPLATE = "message-handled-error.ftl";
    public static final String MESSAGE_RECOVERED_SUCCESS_TEMPLATE = "message-recovered-success.ftl";

    public RtbSupportEmailService(EmailService emailService) {
        this.emailService = emailService;
    }

    public void sendMessageHandledError(Map<String, Object> data) {
        String subjectTemplate = "ERROR: AGS Failed to process message: ${producerId}-${correlationId}";
        this.sendEmail(subjectTemplate, MESSAGE_HANDLED_ERROR_TEMPLATE, data);
    }
    public void sendMessageRecoverSuccess(Map<String, Object> data) {
        String subjectTemplate = "INFO: AGS Successful to recover process message: ${producerId}-${correlationId}";
        this.sendEmail(subjectTemplate, MESSAGE_RECOVERED_SUCCESS_TEMPLATE, data);
    }

    private void sendEmail(String subjectTemplate, String contentTemplate, Map<String, Object> data) {
        if (!emailService.isEnabled()) {
            logger.info("RTB support email is disabled. Skipping email send. subjectTemplate={}", subjectTemplate);
            return;
        }

        Email email = new Email();
        try {
            email.setSubjectTemplate(subjectTemplate);
            email.setContentTemplate(contentTemplate);

            emailService.send(email, data);
            logger.info("Successful to send support email. subject={}, emailBody={}", email.getSubject(), email.getContent());
        } catch (Exception e) {
            logger.error("Failed to send support email. subject={}, emailBody={}", email.getSubject(), email.getContent());
        }
    }

}
