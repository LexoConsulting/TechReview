package com.rbc.rbccm.yog0.ags.config;

import com.rbc.rbccm.yog0.ags.config.channel.JmsServerConfig;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashMap;
import java.util.Map;

@ConfigurationProperties(prefix = "ags-app")
public class AppConfig {
    private String storagePath;
    private int healthCheckIntervalSeconds;

    private Map<String, JmsServerConfig> jmsServers = new HashMap<>();
    private Map<String, FlowConfig> flows = new HashMap<>();

    @PostConstruct
    private void init() {
        for(FlowConfig flow : flows.values()) {
            flow.getSourceChannel().setJmsServerConfig(jmsServers.get(flow.getSourceChannel().getJmsServer()));
            flow.getDestinationChannel().setJmsServerConfig(jmsServers.get(flow.getDestinationChannel().getJmsServer()));
        }
    }

    public AppConfig() {
    }

    public String getStoragePath() {
        return storagePath;
    }

    public void setStoragePath(String storagePath) {
        this.storagePath = storagePath;
    }

    public int getHealthCheckIntervalSeconds() {
        return healthCheckIntervalSeconds;
    }

    public void setHealthCheckIntervalSeconds(int healthCheckIntervalSeconds) {
        this.healthCheckIntervalSeconds = healthCheckIntervalSeconds;
    }

    public Map<String, JmsServerConfig> getJmsServers() {
        return jmsServers;
    }

    public void setJmsServers(Map<String, JmsServerConfig> jmsServers) {
        this.jmsServers = jmsServers;
    }

    public Map<String, FlowConfig> getFlows() {
        return flows;
    }

    public void setFlows(Map<String, FlowConfig> flows) {
        this.flows = flows;
    }

}
