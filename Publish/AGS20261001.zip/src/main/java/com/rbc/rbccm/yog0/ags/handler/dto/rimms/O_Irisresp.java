package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

import java.nio.charset.StandardCharsets;

public class O_Irisresp extends Irisresp {
    public byte[] marshal() {
        String payload = String.join("|",
                safe(reply_pway_sys),
                safe(reply_source_sys),
                safe(reply_hdr_sid),
                safe(reply_ac_batch_id),
                safe(reply_dtl_sid),
                safe(reply_msg_status),
                safe(reply_msg_nbr),
                safe(reply_msg_text),
                safe(reply_msg_text_1)
        );
        return payload.getBytes(StandardCharsets.UTF_8);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
