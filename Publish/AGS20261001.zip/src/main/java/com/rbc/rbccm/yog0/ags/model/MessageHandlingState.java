package com.rbc.rbccm.yog0.ags.model;

import java.io.Serializable;
import java.time.Instant;
import java.util.Map;

public class MessageHandlingState implements Serializable {
    private int attemptCount;
    private Instant firstAttemptTime;
    private Instant lastAttemptTime;
    private Map<String, String> headers;

    public MessageHandlingState(int attemptCount, Instant firstAttemptTime, Instant lastAttemptTime, Map<String, String> headers) {
        this.attemptCount = attemptCount;
        this.firstAttemptTime = firstAttemptTime;
        this.lastAttemptTime = lastAttemptTime;
        this.headers = headers;
    }

    public void incrementAttemptCount() {
        this.attemptCount++;
        this.lastAttemptTime = Instant.now();
    }

    @Override
    public String toString() {
        return "MessageHandlingState{" +
                "attemptCount=" + attemptCount +
                ", firstAttemptTime=" + firstAttemptTime +
                ", lastAttemptTime=" + lastAttemptTime +
                ", headers=" + headers +
                '}';
    }

    public int getAttemptCount() {
        return attemptCount;
    }

    public void setAttemptCount(int attemptCount) {
        this.attemptCount = attemptCount;
    }

    public Instant getFirstAttemptTime() {
        return firstAttemptTime;
    }

    public void setFirstAttemptTime(Instant firstAttemptTime) {
        this.firstAttemptTime = firstAttemptTime;
    }

    public Instant getLastAttemptTime() {
        return lastAttemptTime;
    }

    public void setLastAttemptTime(Instant lastAttemptTime) {
        this.lastAttemptTime = lastAttemptTime;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }
}
