package com.rbc.rbccm.yog0.ags.handler;

import com.fasterxml.jackson.core.JacksonException;
import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryResponse;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.I_Irisresp;
import com.rbc.rbccm.yog0.ags.model.exception.CantRetrieveHeadersException;
import com.rbc.rbccm.yog0.ags.model.exception.MessageTransformationException;
import com.rbc.rbccm.yog0.ags.transformer.RimmsResponseMessageTransformer;
import com.rbc.rbccm.yog0.ags.util.JsonUtil;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import io.micrometer.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Map;

public class RimmsResponseMessageHandler extends AbstractMessageHandler<I_Irisresp, AccountingEntryResponse>{
    private static final Logger logger = LoggerFactory.getLogger(RimmsResponseMessageHandler.class);

    private final RimmsResponseMessageTransformer rimmsResponseMessageTransformer;

    public RimmsResponseMessageHandler() {
        this.rimmsResponseMessageTransformer = SpringContextUtil.getBean(RimmsResponseMessageTransformer.class);
    }

    protected I_Irisresp populateRequest(Object message) throws JacksonException {
        if (message == null) {
            throw new MessageTransformationException("RIMMS response body cannot be null or empty");
        }

        byte[] messageArray = (byte[])message;
        try {
            I_Irisresp iIrisresp = new I_Irisresp();
            iIrisresp.unmarshal(messageArray, messageArray.length);
            return iIrisresp;
        } catch (Exception e) {
            throw new MessageTransformationException("Failed to unmarshal RIMMS response", e);
        }
    }

    protected String buildMessageKey(I_Irisresp request, Map<String, String> headers) {
        // Remove leading zeros from SID
        String sid = request.reply_hdr_sid.replaceFirst("^0+(?!$)", "");

        String messageKey = String.format("%s-%s", request.reply_source_sys, sid);

        // Add headers to MDC
        MDC.put("corrId", String.format("%s", messageKey));

        return messageKey;
    }

    protected void retrieveMessageHeaders(String messageKey, Map<String, String> headers) {
        // Use the messageKey to retrieve related request headers
        Map<String, String> headersOfRequest = this.flowProcessor.findAndRemoveRelatedInboundFlowMessageHeaders(messageKey);
        if (headersOfRequest != null) {
            headers.putAll(headersOfRequest);
            logger.info("Found related inbound flow message headers, add to this response header: {}", headers);
        } else {
            logger.warn("No related flow message headers found by messageKey: {}", messageKey);
            throw new CantRetrieveHeadersException("No related flow message headers found by messageKey: " + messageKey);
        }

    }

    protected AccountingEntryResponse transformRequest(I_Irisresp request) {
        try {
            return rimmsResponseMessageTransformer.transform(request);
        } catch (Exception e) {
            throw new MessageTransformationException("Failed to transform RIMMS response to AccountingEntryResponse", e);
        }
    }

    protected void sendToDestinationChannel(AccountingEntryResponse destRequest, String messageKey, Map<String, String> headers) {
        Integer partition = destChannelConfig.getPartition();
        Map<String, Integer> producerPartitions = destChannelConfig.getProducerPartitions();
        if (producerPartitions != null && !producerPartitions.isEmpty()) {
            partition = producerPartitions.get(destRequest.sourceSystemCode());
            logger.debug("producerPartitions is defined, use the partition: {} based on the source system code: {}", partition, destRequest.sourceSystemCode());
        }

        if (partition == null || partition == -1) {
            logger.info("RIMMS response has partition: {} defined for source system code: {}. Don't send this message to destination", partition, destRequest.sourceSystemCode());
            return;
        }
        String destination = destChannelConfig.getDestination();
        if (StringUtils.isEmpty(destination)) {
            logger.info("RIMMS response has no destination defined, Don't send this message");
            return;
        }

        String transformedBody = JsonUtil.toJson(destRequest);

        this.destChannelProducer.send(messageKey, transformedBody, partition, headers);
        logger.info("RIMMS response sent to destination/partition[{}/{}]: {}", destChannelConfig.getDestination(), partition, transformedBody);
    }


}
