package com.rbc.rbccm.yog0.ags.adapter.activemq;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import io.micrometer.common.util.StringUtils;
import jakarta.jms.BytesMessage;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import java.util.Map;

public class ActiveMQProducer extends AbstractJmsProducer {
    private static final Logger logger = LoggerFactory.getLogger(ActiveMQProducer.class);

    private final JmsTemplate jmsTemplate;

    public ActiveMQProducer(String flowName, ChannelConfig channelConfig) {
        super(flowName, channelConfig);

        ConnectionFactory connectionFactory = ActiveMQConnectionFactoryProvider.getConnectionFactory(flowName, channelConfig);
        this.jmsTemplate = new JmsTemplate(connectionFactory);
    }

    public void send(String messageKey, Object message, Integer partition, Map<String, String> headers) {
        if (message == null) {
            throw new IllegalArgumentException("Payload cannot be null");
        }

        String destination = StringUtils.isNotEmpty(this.channelConfig.getQueue()) ? this.channelConfig.getQueue(): this.channelConfig.getTopic();
        if (message instanceof byte[]) {
            byte[] payload = (byte[])message;

            jmsTemplate.send(destination, session -> {
                BytesMessage bytesMessage = session.createBytesMessage();
                bytesMessage.writeBytes(payload);
                return bytesMessage;
            });
            logger.info("Sent byte[] message: {} to destination. Payload length: {} bytes", messageKey, payload.length);
        } else {
            String payload = message.toString();

            // Send to destination topic as String text
            jmsTemplate.send(destination, session -> {
                TextMessage textMessage = session.createTextMessage(message.toString());
                return textMessage;
            });

            logger.info("Sent text message: {} to destination. Payload length: {} bytes",
                    messageKey, payload.length());
        }
    }
}
