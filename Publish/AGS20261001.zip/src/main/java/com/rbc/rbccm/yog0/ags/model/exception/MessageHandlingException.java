package com.rbc.rbccm.yog0.ags.model.exception;

public class MessageHandlingException extends RuntimeException {
    public MessageHandlingException(String message) {
        super(message);
    }

    public MessageHandlingException(String message, Throwable cause) {
        super(message, cause);
    }
}

