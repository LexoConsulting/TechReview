package com.rbc.rbccm.yog0.ags.config;

import jakarta.servlet.DispatcherType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Value("${server.ssl.trust-store:}")
    private String trustStoreLocation;
    @Value("${server.ssl.trust-store-password:}")
    private String trustStorePassword;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // CSRF protection is disabled for this RESTful API application
                // Justification: This is a stateless RESTful API that does not use browser-based
                // session cookies for authentication. CSRF protection is not required.
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(authz -> authz
                        .dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()
                        .requestMatchers("/api/v1/health", "/api/v1/ping", "/api/v1/info", "/api/v1/listStoragePath",
                                "/api/v1/piv/send-flow-inbound-message", "/api/v1/piv/send-flow-outbound-message"
                        ).permitAll()
                        .requestMatchers("/actuator/health", "/actuator/health/liveness", "/actuator/health/readiness", "/actuator/info", "/actuator/metrics", "/actuator/prometheus", "/actuator/env", "/actuator/loggers", "/actuator/shutdown").permitAll()
                        .requestMatchers("/v3/api-docs", "/swagger-ui/index.html", "/error").permitAll()
                        .anyRequest().authenticated()
                );

        return http.build();
    }

    public String getTrustStoreLocation() {
        return this.trustStoreLocation;
    }
    public String getTrustStorePassword() {
        return this.trustStorePassword;
    }
}


