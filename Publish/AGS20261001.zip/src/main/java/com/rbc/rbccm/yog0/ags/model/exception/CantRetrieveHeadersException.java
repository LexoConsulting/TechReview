package com.rbc.rbccm.yog0.ags.model.exception;

public class CantRetrieveHeadersException extends RuntimeException {
    public CantRetrieveHeadersException(String message) {
        super(message);
    }

    public CantRetrieveHeadersException(String message, Throwable cause) {
        super(message, cause);
    }
}