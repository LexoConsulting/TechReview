package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class O_IrisreqDetail extends IrisreqDetail {
    public String marshal() {
        return String.join("|",
                safe(this.book_date_yyyy),
                safe(this.book_date_mm),
                safe(this.book_date_dd),
                safe(this.iris_dtl_sid),
                safe(this.cr_dr_id),
                safe(this.nbr),
                safe(this.typ),
                safe(this.ccy),
                safe(this.ref),
                safe(this.sbr),
                safe(this.amt),
                safe(this.sid_text),
                safe(this.vat),
                safe(this.fac),
                safe(this.filler0)
        );
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
