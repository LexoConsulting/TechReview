package com.rbc.rbccm.yog0.ags.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

public class InputSanitizer {
    private static final Logger logger = LoggerFactory.getLogger(InputSanitizer.class);
    
    // Pattern for valid Linux directory path: allows absolute (starts with /) or relative paths
    // Allows alphanumeric, hyphen, underscore, dots, slashes
    // Disallows .. for path traversal attacks
    private static final Pattern VALID_DIR_PATTERN = Pattern.compile("^/?([a-zA-Z0-9_\\-./]+)?$");
    
    public static String sanitizeDir(String dir) {
        if (dir == null || dir.trim().isEmpty()) {
            logger.warn("Directory path is null or empty");
            return "";
        }
        
        String trimmedDir = dir.trim();
        
        // Check for path traversal attempts
        if (trimmedDir.contains("..")) {
            logger.warn("Directory path contains path traversal attempt: {}", trimmedDir);
            throw new IllegalArgumentException("Directory path cannot contain '..' for security reasons");
        }
        
        // Check for null bytes
        if (trimmedDir.contains("\0")) {
            logger.warn("Directory path contains null byte: {}", trimmedDir);
            throw new IllegalArgumentException("Directory path cannot contain null bytes");
        }
        
        // Validate against the pattern
        if (!VALID_DIR_PATTERN.matcher(trimmedDir).matches()) {
            logger.warn("Directory path contains invalid characters: {}", trimmedDir);
            throw new IllegalArgumentException("Directory path contains invalid characters. Only alphanumeric, hyphens, underscores, dots, and forward slashes are allowed");
        }
        
        // Normalize the path (remove duplicate slashes, trailing slash unless it's root or single dot)
        String normalized = trimmedDir.replaceAll("/+", "/");
        if (normalized.length() > 1 && normalized.endsWith("/")) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }
        
        // Handle empty string (just "/" becomes "")
        if (normalized.isEmpty()) {
            normalized = "/";
        }
        
        logger.debug("Sanitized directory path: {} -> {}", dir, normalized);
        return normalized;
    }

    public static String resolveAndValidatePath(String basePath, String subdir) throws IOException {
        if (StringUtils.isEmpty(basePath)) {
            throw new IllegalArgumentException("Base path cannot be empty");
        }

        Path base = Paths.get(basePath).toAbsolutePath().normalize();
        if (StringUtils.isEmpty(subdir) || "/".equals(subdir)) {
            return base.toString();
        }
        String sanitized = sanitizeDir(subdir);
        Path resolved = base.resolve(sanitized).normalize();
        if (resolved.startsWith(base)) {
            throw new SecurityException("Path traversal attempt detected");
        }
        return resolved.toString();
    }
}
