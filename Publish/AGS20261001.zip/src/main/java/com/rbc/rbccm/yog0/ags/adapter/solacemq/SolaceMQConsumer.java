package com.rbc.rbccm.yog0.ags.adapter.solacemq;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConsumer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.handler.AbstractMessageHandler;
import io.micrometer.common.util.StringUtils;
import jakarta.jms.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.SessionAwareMessageListener;

public class SolaceMQConsumer extends AbstractJmsConsumer {
    private static final Logger logger = LoggerFactory.getLogger(SolaceMQConsumer.class);
    private final jakarta.jms.ConnectionFactory connectionFactory;

    public SolaceMQConsumer(String flowName, ChannelConfig channelConfig) {
        super(flowName, channelConfig);

        this.connectionFactory = SolaceMQConnectionFactoryProvider.getConnectionFactory(flowName, channelConfig);
    }

    @Override
    protected ConnectionFactory getConnectionFactory() {
        return this.connectionFactory;
    }

    @Override
    public void startListening(AbstractMessageHandler<?, ?> messageHandler) {
        // For Solace MQ, we always listen to a Queue
        String destinationName = this.channelConfig.getQueue();
        String containerId = getContainerId();
        if (isListening()) {
            logger.info("JMS listener already running for flow [{}] on destination [{}]. Skipping duplicate listener startup.", this.flowName, destinationName);
            return;
        }
        logger.info("Starting {} listener for flow [{}] on destination queue [{}]", this.getClass().getSimpleName(), this.flowName, destinationName);

        try {
            logger.info("Creating DefaultMessageListenerContainer for flow [{}] on destination [{}]", flowName, destinationName);
            DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
            container.setConnectionFactory(connectionFactory);
            container.setDestinationName(destinationName);
            container.setPubSubDomain(false); // queue => false, topic => true
            container.setBeanName(containerId);

            long retryInterval = channelConfig.getJmsServerConfig().getRetryIntervalSeconds();
            container.setRecoveryInterval(retryInterval * 1000); // Convert seconds to milliseconds

            // Direct transport is disabled on the Solace connection factory, so transacted sessions are supported here.
            container.setSessionTransacted(true);

            // For transacted listeners -> downstream processing failures are rethrown so JMS session can roll back and redeliver
            // For non-transacted listeners -> default ack behaviour applies

            SessionAwareMessageListener listener = (message, session) -> {
                boolean toAck = this.onMessageReceived(messageHandler, message);
                if (toAck) {
                    try {
                        session.commit();
                        logger.debug("JMS message committed successfully for flow [{}]", flowName);
                    } catch (JMSException e) {
                        logger.error("Failed to commit JMS session for flow [{}]: {}", flowName, e.getMessage(), e);
                        throw new RuntimeException("Failed to commit JMS session", e);
                    }
                } else {
                    try {
                        session.rollback();
                        logger.info("JMS message rolled back (NACK) for flow [{}]", flowName);
                    } catch (JMSException e) {
                        logger.error("Failed to rollback JMS session for flow [{}]: {}", flowName, e.getMessage(), e);
                        throw new RuntimeException("Failed to rollback JMS session", e);
                    }
                }
            };

            container.setMessageListener(listener);

            logger.info("Calling afterPropertiesSet() on JMS listener container [{}] for flow [{}] on destination [{}]", containerId, flowName, destinationName);
            container.afterPropertiesSet();

            logger.info("Starting JMS listener container [{}] for flow [{}] on destination [{}]", containerId, flowName, destinationName);
            container.start();

            listenerContainers.put(containerId, container);
            logger.info("JMS listener started successfully for flow [{}] on destination [{}]", flowName, destinationName);

        } catch (Exception e) {
            logger.error("Failed to start JMS listener for flow [{}] on destination [{}]: {}", flowName, destinationName, e.getMessage(), e);
            throw new RuntimeException("Failed to start JMS listener for flow [" + flowName + "] on destination [" + destinationName + "]: " + e.getMessage(), e);
        }
    }

}
