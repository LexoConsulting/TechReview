package com.rbc.rbccm.yog0.ags.scheduler;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConsumer;
import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConnectionFactory;
import com.rbc.rbccm.yog0.ags.config.FlowConfig;
import com.rbc.rbccm.yog0.ags.handler.AbstractMessageHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FlowProcessor {
    private static final Logger logger = LoggerFactory.getLogger(FlowProcessor.class);

    private final String flowName;
    private final FlowConfig flowConfig;
    private List<FlowProcessor> relatedInboundFlows = new ArrayList<>();

    private final AbstractMessageHandler<?, ?> messageHandler;

    private final AbstractJmsConsumer sourceChannelConsumer;
    private final AbstractJmsProducer sourceChannelProducer; // For PIV Testing purpose

    public FlowProcessor(String storagePath, String flowName, FlowConfig flowConfig) {
        this.flowName = flowName;
        this.flowConfig = flowConfig;

        this.sourceChannelConsumer = AbstractJmsConnectionFactory.createJmsConsumer(flowName, flowConfig.getSourceChannel());
        this.sourceChannelProducer = AbstractJmsConnectionFactory.createJmsProducer(flowName, flowConfig.getSourceChannel());

        AbstractJmsProducer destChannelProducer = AbstractJmsConnectionFactory.createJmsProducer(flowName, flowConfig.getDestinationChannel());
        try {
            Class<?> clazz = Class.forName(flowConfig.getMessageHandlerClass());
            this.messageHandler = (AbstractMessageHandler<?, ?>) clazz.getDeclaredConstructor().newInstance();

            this.messageHandler.init(this.flowName, storagePath, flowConfig.getSourceChannel(), flowConfig.getDestinationChannel(), destChannelProducer, this);
        } catch (Exception e) {
            throw new IllegalArgumentException("Failed to create message handler instance from: " + flowConfig.getMessageHandlerClass(), e);
        }
    }

    /**
     * When start flow:
     * - Start listen to the source channel.
     * - Handle the message from source channel.
     * - Transform the message.
     * - Send the message to destination channel.
     */
    public void startFlow() {
        if (!flowConfig.isEnabled()) {
            logger.debug("Flow: {} is not enabled", flowName);
            return;
        }

        try {
            logger.info("Begin starting flow {}", flowName);

            this.sourceChannelConsumer.startListening(this.messageHandler);

            logger.info("End starting flow {}", flowName);
        } catch (Exception e) {
            logger.error("Failed to start source channel adapter", e);
        }
    }

    public void shutdown() {
        try {
            this.sourceChannelConsumer.stopListening();
        } catch (Exception e) {
            logger.error("Failed to start source channel adapter", e);
        }

        this.messageHandler.shutdown();
    }

    public void checkHealth() {
        // Check the consumer is running
        boolean listenerRunning = this.sourceChannelConsumer.isListening();
        boolean serverAvailable = sourceChannelConsumer.isServerAvailable();

        if (!serverAvailable) {
            if (listenerRunning) {
                sourceChannelConsumer.stopListening();
                logger.warn("HealthCheck for {}: Server is not available, stop the listener", this.flowName);
            } else {
                logger.warn("HealthCheck for {}: Server is not available, listener is stopped.", flowName);
            }
        } else {
            // Broker is available
            if (listenerRunning) {
                // it is listening, no need to do anything
                logger.info("HealthCheck for {}: Server is available, and the listener is running", flowName);
            } else {
                // Try to restart it
                this.sourceChannelConsumer.startListening(this.messageHandler);
                logger.info("HealthCheck for {}: Server is available, listener is not running, started it", flowName);
            }
        }
    }

    public Map<String, String> findAndRemoveRelatedInboundFlowMessageHeaders(String messageKey) {
        for (FlowProcessor flowProcessor : relatedInboundFlows) {
            Map<String, String> headers = flowProcessor.findAndRemoveMessageHeaders(messageKey);
            if (headers != null) {
                return headers;
            }
        }

        return null;
    }

    public Map<String, String> findAndRemoveMessageHeaders(String messageKey) {
        Map<String, String> headers = this.messageHandler.findAndRemoveMessageHeaders(messageKey);
        if (headers != null) {
            logger.info("The Response flow is triggered, found and return the headers from request flow: {}, remove message headers from request flow", this.flowName);
        }
        return headers;
    }

    public AbstractMessageHandler<?, ?> getMessageHandler() {
        return this.messageHandler;
    }

    public AbstractJmsProducer getSourceChannelProducer() {
        return sourceChannelProducer;
    }

    public FlowConfig getFlowConfig() {
        return flowConfig;
    }

    public void addRelatedInboundFlow(FlowProcessor flowProcessor) {
        relatedInboundFlows.add(flowProcessor);
    }

    public FlowInfo getFlowInfo() {
        FlowInfo flowInfo = new FlowInfo();
        flowInfo.setFlowName(this.flowName);
        flowInfo.setNumberOfMessagesInCache(this.messageHandler.getNumberOfMessageInCache());
        flowInfo.setMessageKeysInCache(this.messageHandler.getMessageKeysInCache());

        return flowInfo;
    }

    public static class FlowInfo {
        private String flowName;
        private int numberOfMessagesInCache;
        private String messageKeysInCache;

        public String getFlowName() {
            return flowName;
        }

        public void setFlowName(String flowName) {
            this.flowName = flowName;
        }

        public int getNumberOfMessagesInCache() {
            return numberOfMessagesInCache;
        }

        public void setNumberOfMessagesInCache(int numberOfMessagesInCache) {
            this.numberOfMessagesInCache = numberOfMessagesInCache;
        }

        public String getMessageKeysInCache() {
            return messageKeysInCache;
        }

        public void setMessageKeysInCache(String messageKeysInCache) {
            this.messageKeysInCache = messageKeysInCache;
        }
    }
}
