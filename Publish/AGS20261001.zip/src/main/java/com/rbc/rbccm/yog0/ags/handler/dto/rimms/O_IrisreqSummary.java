package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class O_IrisreqSummary extends IrisreqSummary {
    public String marshal() {
        return String.join("|",
                safe(this.source_sys_code),
                safe(this.iris_hdr_sid),
                safe(this.batch_date_yyyy),
                safe(this.batch_date_mm),
                safe(this.batch_date_dd),
                safe(this.hh),
                safe(this.batch_time_mm),
                safe(this.ss),
                safe(this.batch_cr_count),
                safe(this.batch_dr_count),
                safe(this.batch_cr_total),
                safe(this.batch_dr_total),
                safe(this.batch_text),
                safe(this.reversal_ind),
                safe(this.group_number),
                safe(this.group_total),
                safe(this.group_name)
        );
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
