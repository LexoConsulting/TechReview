package com.rbc.rbccm.yog0.ags.model;

import java.util.Objects;

public class AccountingEntryMessageKey {

    private String producerId;
    private String correlationId;

    public AccountingEntryMessageKey(String producerId, String correlationId) {
        this.producerId = producerId;
        this.correlationId = correlationId;
    }

    @Override
    public String toString() {
        return "AccountingEntryMessageKey{" +
                "producerId='" + producerId + '\'' +
                ", correlationId='" + correlationId + '\'' +
                '}';
    }

    public String getProducerId() {
        return producerId;
    }

    public void setProducerId(String producerId) {
        this.producerId = producerId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AccountingEntryMessageKey)) {
            return false;
        }
        AccountingEntryMessageKey that = (AccountingEntryMessageKey) obj;
        return Objects.equals(producerId, that.producerId)
                && Objects.equals(correlationId, that.correlationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(producerId, correlationId);
    }
}
