package com.rbc.rbccm.yog0.ags.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class JsonUtil {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    static {
        // Initlize the ObjectMapper
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
        objectMapper.setTimeZone(TimeZone.getTimeZone("UTC"));
        objectMapper.setDefaultPropertyInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.setDefaultPropertyInclusion(JsonInclude.Include.NON_EMPTY);
    }

    private JsonUtil() {}

    public static <T> T parseJson(String message, Class<T> targetType) throws JacksonException {
        if (message == null || message.isBlank()) {
            return null;
        }

        return objectMapper.readValue(message, targetType);
    }

    public static <T> T parseJson(String message, TypeReference<T> typeReference) throws JacksonException {
        if (message == null || message.isBlank()) {
            return null;
        }

        return objectMapper.readValue(message, typeReference);
    }

    public static String toJson(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialize Object to JSON, should not happens", e);
        }
    }
}
