package com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry;

import com.rbc.rbccm.yog0.ags.model.AccountingEntry;
import com.rbc.rbccm.yog0.ags.model.AccountingEntrySummary;

import java.util.List;

public record AccountingEntryRequest (
    AccountingEntrySummary summary,

    List<AccountingEntry> details
) {
}

