package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class I_IrisreqSummary extends IrisreqSummary{
    public void unmarshal(String line) {
        String[] parts = line.split("\\|", -1);
        int i = 0;
        this.source_sys_code = get(parts, i++);
        this.iris_hdr_sid = get(parts, i++);
        this.batch_date_yyyy = get(parts, i++);
        this.batch_date_mm = get(parts, i++);
        this.batch_date_dd = get(parts, i++);
        this.hh = get(parts, i++);
        this.batch_time_mm = get(parts, i++);
        this.ss = get(parts, i++);
        this.batch_cr_count = get(parts, i++);
        this.batch_dr_count = get(parts, i++);
        this.batch_cr_total = get(parts, i++);
        this.batch_dr_total = get(parts, i++);
        this.batch_text = get(parts, i++);
        this.reversal_ind = get(parts, i++);
        this.group_number = get(parts, i++);
        this.group_total = get(parts, i++);
        this.group_name = get(parts, i);
    }

    private String get(String[] parts, int index) {
        return index < parts.length ? parts[index] : "";
    }
}
