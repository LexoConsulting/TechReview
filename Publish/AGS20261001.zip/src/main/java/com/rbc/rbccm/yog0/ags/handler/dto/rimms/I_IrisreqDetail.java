package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class I_IrisreqDetail extends IrisreqDetail {
    public void unmarshal(String line) {
        String[] parts = line.split("\\|", -1);
        int i = 0;
        this.book_date_yyyy = get(parts, i++);
        this.book_date_mm = get(parts, i++);
        this.book_date_dd = get(parts, i++);
        this.iris_dtl_sid = get(parts, i++);
        this.cr_dr_id = get(parts, i++);
        this.nbr = get(parts, i++);
        this.typ = get(parts, i++);
        this.ccy = get(parts, i++);
        this.ref = get(parts, i++);
        this.sbr = get(parts, i++);
        this.amt = get(parts, i++);
        this.sid_text = get(parts, i++);
        this.vat = get(parts, i++);
        this.fac = get(parts, i++);
        this.filler0 = get(parts, i);
    }

    private String get(String[] parts, int index) {
        return index < parts.length ? parts[index] : "";
    }
}
