package com.rbc.rbccm.yog0.ags.controller;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.rbc.rbccm.yog0.ags.scheduler.ApplicationScheduler;
import com.rbc.rbccm.yog0.ags.scheduler.FlowProcessor;
import com.rbc.rbccm.yog0.ags.util.InputSanitizer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1")
public class ApplicationController {
    private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);

    @Value("${info.app.name}")
    private String appName;
    @Value("${info.app.version}")
    private String appVersion;

    @Value("${ags-app.storage-path:/mnt/data}")
    private String storagePath;
    private String relativePath = "/";
    private static final String RELATIVE_ROOT_DIR = "/";
    private static final String PARENT_DIR = "..";
    private static final String FILE_TYPE_DIR = "DIR";
    private static final String FILE_TYPE_FILE = "FILE";

    @Autowired
    ApplicationScheduler applicationScheduler;

    public static record FileInfo(String fileType, String fileName, long size, String lastUpdated) {
        public String toString() {
            return String.format("%4s, %8d, %19s, %s", fileType, size, lastUpdated, fileName);
        }
    }

    public static record AppInfo(String appName, String appVersion, List<FlowProcessor.FlowInfo> flows) {
    }


    @GetMapping("/ping")
    public String ping() {
        return "Pong";
    }

    @GetMapping("/info")
    public AppInfo info() {
        List<FlowProcessor.FlowInfo> flowInfos = new ArrayList<>();
        Map<String, FlowProcessor> flows = applicationScheduler.getFlows();
        for (Map.Entry<String, FlowProcessor> entry : flows.entrySet()) {
            FlowProcessor.FlowInfo flowInfo = entry.getValue().getFlowInfo();
            flowInfos.add(flowInfo);
        }

        return new AppInfo(appName, appVersion, flowInfos);
    }

    @GetMapping(value = "/listStoragePath")
    @ResponseBody
    public List<String> listStoragePath(@RequestParam Map<String, String> searchParams) {
        String dirToGo = searchParams.get("dirToGo");
        logger.info("listStoragePath() for {}", dirToGo);
        if (!PARENT_DIR.equals(dirToGo)) {
            dirToGo = InputSanitizer.sanitizeDir(dirToGo);
        }

        if (StringUtils.isEmpty(dirToGo)) {
            this.relativePath = RELATIVE_ROOT_DIR;
        } else {
            if (PARENT_DIR.equals(dirToGo)) {
                int lastIndex = this.relativePath.lastIndexOf(RELATIVE_ROOT_DIR);
                if (lastIndex >= 0) {
                    this.relativePath = relativePath.substring(0, lastIndex);
                }
            } else {
                if (!relativePath.endsWith("/")) {
                    relativePath += "/";
                }
                relativePath += dirToGo;
            }
        }
        if (StringUtils.isEmpty(this.relativePath)) {
            this.relativePath = RELATIVE_ROOT_DIR;
        }

        String path = this.storagePath + this.relativePath;
        List<String> result = new ArrayList<>();
        result.add(String.format("Current Path: %s", path));
        this.listStoragePath(result, path);

        return result;
    }

    private void listStoragePath(List<String> result, String storagePath) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        List<FileInfo> fileInfos = new ArrayList<>();
        if (!relativePath.equals(RELATIVE_ROOT_DIR) ) {
            fileInfos.add(new FileInfo(FILE_TYPE_DIR, "..", 0, ""));
        }
        try {
            Path dir = Paths.get(storagePath);
            List<Path> sortedFiles = Files.list(dir)
                    // .filter(Files::isRegularFile)
                    .sorted(Comparator.comparing(item -> {
                        try {
                            return Files.getLastModifiedTime((Path)item);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }).reversed())
                    .toList();

            // Print sorted files
            sortedFiles.forEach(path -> {
                try {
                    File file = path.toFile();
                    BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
                    LocalDateTime lastModified = LocalDateTime.ofInstant(
                            Instant.ofEpochMilli(attrs.lastModifiedTime().toMillis()),
                            ZoneId.systemDefault()
                    );
                    FileInfo fileInfo = new FileInfo(file.isFile() ? FILE_TYPE_FILE : FILE_TYPE_DIR,
                            file.getName(), file.length(), lastModified.format(formatter));

                    fileInfos.add(fileInfo);
                } catch (IOException e) {
                    logger.warn("Failed to read file attributes: {}", path, e);
                }
            });

        } catch (Exception e) {
            logger.warn("Dir not exist: {}", storagePath);
        }

        result.add(String.format("%4s, %8s, %19s, %s", "Type", "Size", "lastUpdated", "fileName"));
        for (FileInfo fileInfo : fileInfos) {
            result.add(fileInfo.toString());
        }
    }

}
