package com.rbc.rbccm.yog0.ags.adapter.kafka;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsConnectionFactory;
import com.rbc.rbccm.yog0.ags.config.SecurityConfig;
import com.rbc.rbccm.yog0.ags.config.channel.JmsServerConfig;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import io.micrometer.common.util.StringUtils;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.security.auth.SecurityProtocol;
import org.apache.kafka.common.serialization.StringDeserializer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.clients.consumer.ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG;

public class KafkaConnectionFactoryProvider extends AbstractJmsConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConnectionFactoryProvider.class);

    public static ConsumerFactory<String, String> createConsumerFactory(String flowName, ChannelConfig config) {
        JmsServerConfig jmsServerConfig = config.getJmsServerConfig();

        // 1. Define dynamic configuration maps
        Map<String, Object> configProps = setupCommonProperties(jmsServerConfig.getServers());

        // Apply JAAS configuration from source channel config
        if (jmsServerConfig.getServers().startsWith("localhost")) {
            logger.info("For Kakfa in Local, skip the security setup when create ConsumerFactory");
        } else {
            setupSecurity(configProps, jmsServerConfig.getKafkaPrincipal(), jmsServerConfig.getKafkaKeytab());
        }

        // Consumer Specific Properties
        configProps.put(CommonClientConfigs.CLIENT_ID_CONFIG, jmsServerConfig.getClientUsername());
        configProps.put(CommonClientConfigs.GROUP_ID_CONFIG, config.getConsumerGroup());

        // Multiple app replicas (e.g. 2 Docker pods) run identical flow configs, each pinned to the
        // same fixed partition for a given client (eg. IPAY always partition 0, RIBS always partition
        // 1 of the same shared topic). PinnedPartitionAssignor makes Kafka's own group-rebalance
        // protocol grant that partition to exactly one alive replica at a time (active/primary), and
        // automatically fail it over to the other replica (standby) if the active one's session times
        // out - no external leader-election/locking needed.
        configProps.put (ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG, Collections.singletonList(PinnedPartitionAssignor.class.getName()));
        configProps.put(PinnedPartitionAssignor.PINNED_PARTITION_CONFIG, config.getPartition()) ;

        // 2. Return the instantiated Factory with explicit String deserializers
        return new DefaultKafkaConsumerFactory<>(
                configProps,
                new StringDeserializer(),
                new StringDeserializer()
        );
    }

    public static ProducerFactory<String, String> createProducerFactory(String flowName, ChannelConfig config) {
        JmsServerConfig jmsServerConfig = config.getJmsServerConfig();

        // 1. Define dynamic configuration maps
        Map<String, Object> configProps = setupCommonProperties(jmsServerConfig.getServers());

        if (StringUtils.isNotEmpty(jmsServerConfig.getClientUsername())) {
            configProps.put(ProducerConfig.CLIENT_ID_CONFIG, jmsServerConfig.getClientUsername());
        }

        // Apply JAAS configuration from source channel config
        if (jmsServerConfig.getServers().startsWith("localhost")) {
            logger.info("For Kakfa in Local, skip the security setup");
        } else {
            setupSecurity(configProps, jmsServerConfig.getKafkaPrincipal(), jmsServerConfig.getKafkaKeytab());
        }

        return new DefaultKafkaProducerFactory<>(configProps);
    }

    private static Map<String, Object> setupCommonProperties(String servers) {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, servers);
        configProps.put(ProducerConfig.MAX_BLOCK_MS_CONFIG, 10000);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

        configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringSerializer.class);

        // Configure reconnect backoff to reduce connection retry frequency when broker is unavailable
        // This prevents massive WARNING logs
        configProps.put(ConsumerConfig.RECONNECT_BACKOFF_MS_CONFIG, 30000);
        configProps.put(ConsumerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG, 60000);
        configProps.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, 30000);

        return configProps;
    }

    private static void setupSecurity(Map<String, Object> configProps, String jaasPrincipal, String jaasEncodedKeytab) {
        if (StringUtils.isBlank(jaasPrincipal) || "local".equalsIgnoreCase(jaasPrincipal)) {
            logger.info("Skipping Kafka Security setup for Local");
            return;
        }

        configProps.put("security.protocol", SecurityProtocol.SASL_SSL.name());
        configProps.put(SaslConfigs.SASL_MECHANISM, SaslConfigs.GSSAPI_MECHANISM);
        configProps.put("sasl.kerberos.service.name", "kafka");

        try {
            logger.info("Init jaas with sasl. jaas.config property");
            String keytabPath = extractKeytabToTempFile(jaasEncodedKeytab);
            String saslJaasConfig = String.format(
                    "com.sun.security.auth.module.Krb5LoginModule required " +
                            "useKeyTab=true " +
                            "doNotPrompt=true " +
                            "storeKey=true " +
                            "keyTab=\"%s\" " +
                            "principal=\"%s\" " +
                            "useTicketCache=false " +
                            "refreshKrb5Config=true;",
                    keytabPath, jaasPrincipal);
            configProps.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
        } catch (IOException e) {
            logger.error("Failed to init kafka Security", e);
        }
        // Setup the realm
        String realm = jaasPrincipal.substring(jaasPrincipal.indexOf('@') + 1);
        configProps.put("sasl.kerberos.realm", realm);
        System.setProperty("java.security.krb5.realm", realm);
        System.setProperty("java.security.krb5.kdc", realm.toLowerCase());
        System.setProperty("sun.security.krb5.debug", "false");

        SecurityConfig securityConfig = SpringContextUtil.getBean(SecurityConfig.class);
        configProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, securityConfig.getTrustStoreLocation());
        configProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, securityConfig.getTrustStorePassword());

        logger.info("Init the kafka config with principal: {}", jaasPrincipal);
    }

    private static String extractKeytabToTempFile(String jaasEncodedKeytab) throws IOException {
        byte[] decodedKeytab = Base64.getDecoder().decode(jaasEncodedKeytab);
        Path tempKeytabPath;
        try {
            tempKeytabPath = Files.createTempFile("keytab", ".tmp",
                    PosixFilePermissions.asFileAttribute(
                            java.util.EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE)));
        } catch (UnsupportedOperationException e) {
            tempKeytabPath = Files.createTempFile("keytab", ".tmp");
        }
        File tempKeytabFile = tempKeytabPath.toFile();
        tempKeytabFile.deleteOnExit();
        try (FileOutputStream fos = new FileOutputStream(tempKeytabFile)) {
            fos.write(decodedKeytab);
        }
        return tempKeytabFile.getAbsolutePath().replace("\\", "/");
    }

}