package com.rbc.rbccm.yog0.ags.model.enums;

public enum FlowType {
    INBOUND,
    OUTBOUND
}
