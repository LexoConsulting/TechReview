package com.rbc.rbccm.yog0.ags.adapter;

import com.rbc.rbccm.yog0.ags.adapter.activemq.ActiveMQConsumer;
import com.rbc.rbccm.yog0.ags.adapter.activemq.ActiveMQProducer;
import com.rbc.rbccm.yog0.ags.adapter.ibmmq.IbmMQConsumer;
import com.rbc.rbccm.yog0.ags.adapter.ibmmq.IbmMQProducer;
import com.rbc.rbccm.yog0.ags.adapter.kafka.KafkaConsumer;
import com.rbc.rbccm.yog0.ags.adapter.kafka.KafkaProducer;
import com.rbc.rbccm.yog0.ags.adapter.solacemq.SolaceMQConsumer;
import com.rbc.rbccm.yog0.ags.adapter.solacemq.SolaceMQProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.model.enums.JmsServerType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractJmsConnectionFactory {
    private static final Logger logger = LoggerFactory.getLogger(AbstractJmsConnectionFactory.class);

    public AbstractJmsConnectionFactory() {
    }

    /**
     * Create a JMS Message Consumer which
     * - Listen to a topic, consumer the message, acknowledge it
     * - Return the status
     * - Restart Listen
     */
    public static AbstractJmsConsumer createJmsConsumer(String flowName, ChannelConfig channelConfig) {
        JmsServerType type = channelConfig.getJmsServerConfig().getType();

        AbstractJmsConsumer jmsConsumer = switch (type) {
            case KAFKA -> new KafkaConsumer(flowName, channelConfig);
            case ACTIVEMQ -> new ActiveMQConsumer(flowName, channelConfig);
            case IBMMQ -> new IbmMQConsumer(flowName, channelConfig);
            case SOLACEMQ -> new SolaceMQConsumer(flowName, channelConfig);
            default ->
                    throw new IllegalArgumentException("Unsupported channel type: " + type + " for flow: " + flowName);
        };

        // Continue init it
        logger.info("Created Jms Consumer: {}", jmsConsumer);

        return jmsConsumer;
    }

    public static AbstractJmsProducer createJmsProducer(String flowName, ChannelConfig channelConfig) {
        JmsServerType type = channelConfig.getJmsServerConfig().getType();

        AbstractJmsProducer jmsProducer = switch (type) {
            case KAFKA -> new KafkaProducer(flowName, channelConfig);
            case ACTIVEMQ -> new ActiveMQProducer(flowName, channelConfig);
            case IBMMQ -> new IbmMQProducer(flowName, channelConfig);
            case SOLACEMQ -> new SolaceMQProducer(flowName, channelConfig);
            default ->
                    throw new IllegalArgumentException("Unsupported channel type: " + type + " for flow: " + flowName);
        };

        // Continue init it
        logger.info("Created Jms Producer: {}", jmsProducer);

        return jmsProducer;
    }

    protected static String extractHost(String servers) {
        // Format: host:port or just host
        if (servers == null || servers.isBlank()) {
            return "localhost";
        }

        if (servers.startsWith("tcp://")) {
            servers = servers.substring(6);
        }

        String[] parts = servers.split(":");
        return parts[0];
    }

    protected static int extractPort(String servers, int defaultPort) {
        // Format: host:port or just host
        if (servers == null || servers.isBlank()) {
            return defaultPort; // Default Solace SMF port
        }
        if (servers.startsWith("tcp://")) {
            servers = servers.substring(8);
        }

        String[] parts = servers.split(":");
        if (parts.length > 1) {
            try {
                return Integer.parseInt(parts[1]);
            } catch (NumberFormatException e) {
                return defaultPort;
            }
        }
        return 55555;
    }
}