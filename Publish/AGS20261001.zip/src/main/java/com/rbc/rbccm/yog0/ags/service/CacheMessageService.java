package com.rbc.rbccm.yog0.ags.service;

import com.rbc.rbccm.yog0.ags.model.MessageHandlingState;
import com.rbc.rbccm.yog0.ags.util.LRUCache;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Map;

public class CacheMessageService {
    private static final Logger logger = LoggerFactory.getLogger(CacheMessageService.class);

    private final LRUCache<String, MessageHandlingState> messages = new LRUCache<>(1000);

    @Value("${ags-app.appPodName}")
    private String appPodName;

    private String cachePath = "";
    private String cacheFilename = "";

    private int messagesSinceLastSave = 0;
    private static final int SAVE_THRESHOLD = 2;

    public void init(String flowName, String storagePath) {
        this.cachePath = String.format("%s/%s", storagePath, "cache");
        this.cacheFilename = String.format("%s/%s-messages-%s", this.cachePath, flowName, appPodName);

        // List all files in cache path with prefix flowName and load cached data from each file
        try {
            Path cacheDir = Paths.get(this.cachePath);
            if (!Files.exists(cacheDir)) {
                Files.createDirectories(cacheDir);
                logger.info("Created cache directory: {}", cacheDir);
            }
            Files.list(cacheDir)
                .filter(path -> {
                    String fileName = path.toFile().getName();
                    return fileName.startsWith(flowName);
                })
                .forEach(this::loadCacheFile);

            // Save the current messages to disk
            this.saveToDisk();

            // Clean up the files which are created 1 days before
            Files.list(cacheDir)
                .filter(path -> {
                    String fileName = path.toFile().getName();
                    return fileName.startsWith(flowName);
                })
                .filter(path -> path.toFile().lastModified() < System.currentTimeMillis() - 24 * 60 * 60 * 1000)
                .forEach(this::deleteCacheFile);
        } catch (Exception e) {
            logger.warn("Failed to load cached messages from disk: {}, log and continue: {}", this.cachePath, e.getMessage(), e);
        }

    }

    private void loadCacheFile(Path cacheFilePath) {
        File file = cacheFilePath.toFile();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            @SuppressWarnings("unchecked")
            Map<String, MessageHandlingState> loadedMessages = (Map<String, MessageHandlingState>) ois.readObject();
            this.messages.putAll(loadedMessages);
            logger.info("Loaded {} messages from cache file: {}, message keys: {}", loadedMessages.size(), cacheFilePath, messages.keySet());
        } catch (Exception e) {
            logger.warn("Failed to deserialize cache file from: {}, log and continue: {}", cacheFilePath, e.getMessage(), e);
        }
    }
    private void deleteCacheFile(Path cacheFilePath) {
        try {
            File file = cacheFilePath.toFile();
            file.deleteOnExit();
            logger.info("Deleted cache file: {}", cacheFilePath);
        } catch (Exception e) {
            logger.warn("Failed to delete cache file: {}, log and continue: {}", cacheFilePath, e.getMessage(), e);
        }
    }

    public void saveToDisk() {
        if (cacheFilename == null) {
            logger.warn("Cache service not initialized, don't save, return immediately");
            return;
        }

        Path cacheFilePath = Paths.get(this.cacheFilename);
        try {
            // Ensure directory exists
            Path cacheDir = Paths.get(this.cachePath);
            if (!Files.exists(cacheDir)) {
                Files.createDirectories(cacheDir);
                logger.info("Created cache directory: {}", cacheDir);
            }

            // Serialize messages to binary format
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(cacheFilePath.toFile()))) {
                oos.writeObject(this.messages);
            }
            logger.info("Saved {} messages to cache file: {}", this.messages.size(), cacheFilename);
        } catch (Exception e) {
            logger.warn("Failed to save messages to cache file: {} : {}", cacheFilename, e.getMessage(), e);
        }
    }

    public MessageHandlingState findAndRemoveMessage(String messageKey) {
        MessageHandlingState state = this.messages.get(messageKey);
        if (state != null) {
            this.messages.remove(messageKey);
            return state;
        }
        return null;
    }

    public boolean putMessageHeaders(String messageKey, Map<String, String> headers) {
        boolean retryMessage = messages.containsKey(messageKey);

        Instant now = Instant.now();
        MessageHandlingState newState = new MessageHandlingState(1, now, now, headers);
        MessageHandlingState existingState = messages.putIfAbsent(messageKey, newState);
        if (existingState != null) {
            existingState.incrementAttemptCount();
            existingState.setLastAttemptTime(now);
        }
        logger.info("Put the message: {} into messages(total: {}), retryMessage={}, existingState={}", messageKey, this.messages.size(), retryMessage, existingState);

        // Save to disk periodically to avoid too frequent I/O operations
        messagesSinceLastSave++;
        if (messagesSinceLastSave >= SAVE_THRESHOLD) {
            this.saveToDisk();
            messagesSinceLastSave = 0;
        }

        return retryMessage;
    }

    public void removeMessage(String messageKey) {
        this.messages.remove(messageKey);
    }

    @PreDestroy
    public void shutdown() {
        logger.info("CacheMessageService shutting down, saving remaining messages to disk");
        this.saveToDisk();
    }

    public int getNumberOfMessageInCache() {
        return this.messages.size();
    }
    public String getMessageKeysInCache() {
        return this.messages.keySet().toString();
    }
}
