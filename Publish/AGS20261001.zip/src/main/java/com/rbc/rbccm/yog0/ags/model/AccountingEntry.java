package com.rbc.rbccm.yog0.ags.model;

import java.math.BigDecimal;

public record AccountingEntry(
        String year,
        String month,
        String day,
        String sid,
        String payDirection,
        String account,
        String type,
        String currency,
        String classCode,
        String subBranch,
        BigDecimal amount,
        String transactionId
) {
}
