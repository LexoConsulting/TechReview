package com.rbc.rbccm.yog0.ags.controller;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.controller.dto.ApiResponse;
import com.rbc.rbccm.yog0.ags.handler.RimmsResponseMessageHandler;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisresp;
import com.rbc.rbccm.yog0.ags.scheduler.ApplicationScheduler;
import com.rbc.rbccm.yog0.ags.scheduler.FlowProcessor;
import com.rbc.rbccm.yog0.ags.util.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.*;

@RestController
@RequestMapping("/api/v1/piv")
public class PIVController {
    private static final Logger logger = LoggerFactory.getLogger(PIVController.class);

    private final Environment environment;

    @Autowired
    private ApplicationScheduler scheduler;

    private final String prodForbiddenMessage = "This test API is disabled in production";

    public PIVController(Environment environment) {
        this.environment = environment;
    }

    private boolean isProdEnv() {
        List<String> envs = Arrays.asList(environment.getActiveProfiles());
        logger.debug("Active profiles: {}", envs);
        return envs.contains("prod")
                || envs.contains("prod8l") || envs.contains("prodnr") || envs.contains("prodhq");
    }

    @PostMapping("/send-flow-inbound-message")
    public ApiResponse<?> sendFlowInboundMessage(@RequestParam String flow, @RequestParam String producerId, @RequestBody String requestBody) {
        if (this.isProdEnv()) {
            return ApiResponse.error(prodForbiddenMessage, null);
        }

        FlowProcessor flowProcessor = scheduler.findFlowProcessor(flow);
        AbstractJmsProducer jmsProducer = flowProcessor.getSourceChannelProducer();

        Map<String, String> headers = new HashMap<>();
        headers.put("producerId", producerId);
        headers.put("region", "TORONTO");
        headers.put("correlationId", UUID.randomUUID().toString());
        headers.put("timestamp", Instant.now().toString());
        headers.put("schemaVersion", "1.0");

        String messageKey = String.format("%s-%s", headers.get("producerId"), headers.get("correlationId"));
        try {
            jmsProducer.send(messageKey, requestBody, jmsProducer.getChannelConfig().getPartition(), headers);
            return ApiResponse.success("", "Success send message to Kafka request topic");
        } catch (Exception e) {
            return ApiResponse.error("Failed to send message to Kafka reqeust topic", e);
        }
    }

    @PostMapping("/send-flow-outbound-message")
    public ApiResponse<?> sendFlowOutboundMessage(@RequestParam() String flow, @RequestBody String requestBody) {
        if(this.isProdEnv()) {
            return ApiResponse.error(prodForbiddenMessage, null);
        }

        FlowProcessor flowProcessor = scheduler.findFlowProcessor(flow);
        AbstractJmsProducer jmsProducer = flowProcessor.getSourceChannelProducer();

        try {
            O_Irisresp rimmsResp = JsonUtil.parseJson(requestBody, O_Irisresp.class);

            Map<String, String> headers = new HashMap<>();
            String messageKey = String.format("%s-%s", rimmsResp.reply_source_sys, rimmsResp.reply_hdr_sid);

            byte[] payload = rimmsResp.marshal();
            jmsProducer.send(messageKey, payload, jmsProducer.getChannelConfig().getPartition(), headers);
            return ApiResponse.success("", "Success send message to RIMMS request topic");
        } catch (Exception e) {
            return ApiResponse.error("Failed to send message to Kafka request topic", e);
        }
    }



}
