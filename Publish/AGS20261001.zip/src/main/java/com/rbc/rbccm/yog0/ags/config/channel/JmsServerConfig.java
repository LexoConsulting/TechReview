package com.rbc.rbccm.yog0.ags.config.channel;

import com.rbc.rbccm.yog0.ags.model.enums.JmsServerType;

public class JmsServerConfig {
    private JmsServerType type;

    // Kafka contains list of servers, IBM MQ contains queue manager
    private String servers;

    // If Message failed to process, not get ack, how long to retry
    private long retryIntervalSeconds = 60;

    private String clientUsername;
    private String clientPassword;

    // Kafka Specific
    private String kafkaPrincipal;
    private String kafkaKeytab;

    // IBM MQ Specific
    private String queueManager;
    private String mqChannel;

    // Solace MQ Specific
    private String msgVpn;

    @Override
    public String toString() {
        return "JmsServerConfig{" +
                "type=" + type +
                ", servers='" + servers + '\'' +
                ", retryIntervalSeconds=" + retryIntervalSeconds +
                ", clientUsername='" + clientUsername + '\'' +
                ", clientPassword='" + clientPassword + '\'' +
                ", kafkaPrincipal='" + kafkaPrincipal + '\'' +
                ", kafkaKeytab='" + kafkaKeytab + '\'' +
                ", queueManager='" + queueManager + '\'' +
                ", mqChannel='" + mqChannel + '\'' +
                ", msgVpn='" + msgVpn + '\'' +
                '}';
    }

    public JmsServerType getType() {
        return type;
    }

    public void setType(JmsServerType type) {
        this.type = type;
    }

    public String getServers() {
        return servers;
    }

    public void setServers(String servers) {
        this.servers = servers;
    }

    public long getRetryIntervalSeconds() {
        return retryIntervalSeconds;
    }

    public void setRetryIntervalSeconds(long retryIntervalSeconds) {
        this.retryIntervalSeconds = retryIntervalSeconds;
    }

    public String getClientUsername() {
        return clientUsername;
    }

    public void setClientUsername(String clientUsername) {
        this.clientUsername = clientUsername;
    }

    public String getClientPassword() {
        return clientPassword;
    }

    public void setClientPassword(String clientPassword) {
        this.clientPassword = clientPassword;
    }

    public String getKafkaPrincipal() {
        return kafkaPrincipal;
    }

    public void setKafkaPrincipal(String kafkaPrincipal) {
        this.kafkaPrincipal = kafkaPrincipal;
    }

    public String getKafkaKeytab() {
        return kafkaKeytab;
    }

    public void setKafkaKeytab(String kafkaKeytab) {
        this.kafkaKeytab = kafkaKeytab;
    }

    public String getQueueManager() {
        return queueManager;
    }

    public void setQueueManager(String queueManager) {
        this.queueManager = queueManager;
    }

    public String getMqChannel() {
        return mqChannel;
    }

    public void setMqChannel(String mqChannel) {
        this.mqChannel = mqChannel;
    }

    public String getMsgVpn() {
        return msgVpn;
    }

    public void setMsgVpn(String msgVpn) {
        this.msgVpn = msgVpn;
    }
}
