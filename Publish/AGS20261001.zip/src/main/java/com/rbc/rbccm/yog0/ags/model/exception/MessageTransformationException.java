package com.rbc.rbccm.yog0.ags.model.exception;

public class MessageTransformationException extends RuntimeException {
    public MessageTransformationException(String message) {
        super(message);
    }

    public MessageTransformationException(String message, Throwable cause) {
        super(message, cause);
    }
}
