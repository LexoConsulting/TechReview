package com.rbc.rbccm.yog0.ags.transformer;

import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryResponse;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.I_Irisresp;
import com.rbc.rbccm.yog0.ags.model.exception.MessageTransformationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RimmsResponseMessageTransformer implements MessageTransformer<I_Irisresp, AccountingEntryResponse> {
    private static final Logger logger = LoggerFactory.getLogger(RimmsResponseMessageTransformer.class);
    @Override
    public AccountingEntryResponse transform(I_Irisresp message) {
        if (message == null) {
            throw new MessageTransformationException("I_Irisresp cannot be null");
        }

        String msgCode = combineMsgCode(message.reply_msg_status, message.reply_msg_nbr);
        String msgText = combineMsgText(message.reply_msg_text, message.reply_msg_text_1);

        return new AccountingEntryResponse(
                message.reply_pway_sys,
                message.reply_source_sys,
                message.reply_hdr_sid,
                message.reply_ac_batch_id,
                message.reply_dtl_sid,
                msgCode,
                msgText
        );
    }

    private String combineMsgCode(String msgStatus, String msgNbr) {
        if (msgStatus == null && msgNbr == null) {
            return "0000";
        }

        // Make sure the status and nbr has 2 chars and add leading 0 if not
        String status = msgStatus != null ? String.format("%2s", msgStatus).replace(' ', '0') : "00";
        String nbr = msgNbr != null ? String.format("%2s", msgNbr).replace(' ', '0') : "00";

        String msgCode = status + nbr;
        logger.debug("combineMsgCode to {} from status: {} and nbr: {}", msgCode, status, nbr);
        return msgCode;
    }

    private String combineMsgText(String msgText, String msgText1) {
        if (msgText == null && msgText1 == null) {
            return null;
        }

        String text = msgText != null ? msgText : "";
        String text1 = msgText1 != null ? msgText1 : "";
        return (text + text1).trim();
    }
}
