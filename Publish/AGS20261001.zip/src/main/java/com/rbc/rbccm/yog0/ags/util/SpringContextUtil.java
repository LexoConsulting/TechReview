package com.rbc.rbccm.yog0.ags.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class SpringContextUtil implements ApplicationContextAware {
    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    // Get bean by target class type
    public static <T> T getBean(Class<T> beanClass) {
        return context.getBean(beanClass);
    }

    // Get bean by specific qualifier name and class type
    public static <T> T getBean(String name, Class<T> beanClass) {
        return context.getBean(name, beanClass);
    }

    // Autowire a manually-created (non-Spring-managed) instance, so its @Value annotations are processed
    public static void autowireBean(Object bean) {
        context.getAutowireCapableBeanFactory().autowireBean(bean);
    }
}
