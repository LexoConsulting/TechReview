package com.rbc.rbccm.yog0.ags.handler.dto.rimms;

public class Irisresp {

    protected int _bufferLen = 102;
    public String reply_pway_sys;
    public String reply_source_sys;
    public String reply_hdr_sid;
    public String reply_ac_batch_id;
    public String reply_dtl_sid;
    public String reply_msg_status;
    public String reply_msg_nbr;
    public String reply_msg_text;
    public String reply_msg_text_1;

    /**
     * @return the Key information
     */
    public String getKey() {
        return String.format("pway_sys=%s, source_sys_code=%s, sid=%s, batch_id=%s", reply_pway_sys, reply_source_sys, reply_hdr_sid, reply_ac_batch_id);
    }
}
