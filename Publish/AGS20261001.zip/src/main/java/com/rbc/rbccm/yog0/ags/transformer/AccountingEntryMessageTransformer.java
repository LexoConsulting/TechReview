package com.rbc.rbccm.yog0.ags.transformer;

import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryRequest;
import com.rbc.rbccm.yog0.ags.model.exception.MessageTransformationException;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisreq;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_IrisreqDetail;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_IrisreqSummary;
import com.rbc.rbccm.yog0.ags.model.AccountingEntry;
import com.rbc.rbccm.yog0.ags.model.AccountingEntrySummary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Transforms accounting request messages into RIMMS format and back.
 */
@Component
public class AccountingEntryMessageTransformer implements MessageTransformer<AccountingEntryRequest, O_Irisreq> {

    @Override
    public O_Irisreq transform(AccountingEntryRequest message) {
        if (message == null) {
            throw new MessageTransformationException("AccountingEntryRequest cannot be null");
        }

        AccountingEntrySummary summary = message.summary();
        List<AccountingEntry> details = message.details();

        if (summary == null) {
            throw new MessageTransformationException("Missing required field: summary");
        }

        if (details == null || details.isEmpty()) {
            throw new MessageTransformationException("Missing or empty details array");
        }

        O_Irisreq oIrisreq = new O_Irisreq();
        oIrisreq.summary = mapSummary(summary, details.size());
        oIrisreq.details = mapDetails(details);

        // AGS: Position IPY identifier at 10t5h-13th character of SID-TEXT field - https://jira.**
        for(O_IrisreqDetail detail: oIrisreq.details) {
            detail.sid_text = String.format("         %s:%s", oIrisreq.summary.source_sys_code, detail.sid_text);
        }
        return oIrisreq;
    }

    private O_IrisreqSummary mapSummary(AccountingEntrySummary summary, int detailCount) {
        O_IrisreqSummary irisSummary = new O_IrisreqSummary();

        irisSummary.source_sys_code = summary.sourceSystemCode();
        irisSummary.iris_hdr_sid = summary.sid();

        irisSummary.batch_date_yyyy = summary.year();
        irisSummary.batch_date_mm = summary.month();
        irisSummary.batch_date_dd = summary.day();

        irisSummary.hh = summary.hour();
        irisSummary.batch_time_mm = summary.minute();
        irisSummary.ss = summary.second();

        irisSummary.batch_cr_count = toStringOrNull(summary.creditCount());
        irisSummary.batch_dr_count = toStringOrNull(summary.debitCount());
        irisSummary.batch_cr_total = toStringOrNull(summary.creditAmount());
        irisSummary.batch_dr_total = toStringOrNull(summary.debitAmount());

        irisSummary.batch_text = summary.description();
        irisSummary.reversal_ind = normalizeReversal(summary.reversal());

        irisSummary.group_number = "0";
        irisSummary.group_total = String.valueOf(detailCount);
        irisSummary.group_name = "";

        return irisSummary;
    }

    private List<O_IrisreqDetail> mapDetails(List<AccountingEntry> entries) {
        List<O_IrisreqDetail> irisDetails = new ArrayList<>();

        for (AccountingEntry entry : entries) {
            irisDetails.add(mapDetail(entry));
        }

        return irisDetails;
    }

    private O_IrisreqDetail mapDetail(AccountingEntry entry) {
        O_IrisreqDetail irisDetail = new O_IrisreqDetail();

        irisDetail.book_date_yyyy = entry.year();
        irisDetail.book_date_mm = entry.month();
        irisDetail.book_date_dd = entry.day();

        irisDetail.iris_dtl_sid = entry.sid();
        irisDetail.cr_dr_id = normalizePayDirection(entry.payDirection());

        irisDetail.nbr = entry.account();
        irisDetail.typ = entry.type();
        irisDetail.ccy = entry.currency();
        irisDetail.ref = entry.classCode();
        irisDetail.sbr = entry.subBranch();

        irisDetail.amt = toStringOrNull(entry.amount());
        irisDetail.sid_text = entry.transactionId();

        irisDetail.vat = "";
        irisDetail.fac = "";
        irisDetail.filler0 = "";

        return irisDetail;
    }

    private String normalizePayDirection(String payDirection) {
        if (payDirection == null || payDirection.isBlank()) {
            throw new MessageTransformationException("Missing required field: payDirection");
        }

        if (!"CR".equals(payDirection) && !"DR".equals(payDirection)) {
            throw new MessageTransformationException(
                    "Invalid payDirection: " + payDirection + ". Must be 'CR' or 'DR'."
            );
        }

        return payDirection;
    }

    private String normalizeReversal(String reversal) {
        if (reversal == null || reversal.isBlank()) {
            return "";
        }

        if (!"Y".equals(reversal)) {
            throw new MessageTransformationException(
                    "Field reversal must be 'R' or blank, got: " + reversal
            );
        }

        return reversal;
    }

    private String toStringOrNull(Object value) {
        if (value == null) {
            return null;
        }

        if (value instanceof BigDecimal decimal) {
            return decimal.toPlainString();
        }

        return value.toString();
    }

}
