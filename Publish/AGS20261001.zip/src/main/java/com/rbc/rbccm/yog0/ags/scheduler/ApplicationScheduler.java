package com.rbc.rbccm.yog0.ags.scheduler;

import com.rbc.rbccm.yog0.ags.config.AppConfig;
import com.rbc.rbccm.yog0.ags.config.FlowConfig;
import com.rbc.rbccm.yog0.ags.model.enums.FlowType;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class ApplicationScheduler {
    private static final Logger logger = LoggerFactory.getLogger(ApplicationScheduler.class);

    private final AppConfig appConfig;
    private final Map<String, FlowProcessor> flows = new HashMap<>();

    public ApplicationScheduler(AppConfig appConfig) {
        this.appConfig = appConfig;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void startFlows() {
        for(String name: appConfig.getFlows().keySet()) {
            FlowConfig flowConfig = appConfig.getFlows().get(name);
            if (flowConfig.isEnabled()) {
                FlowProcessor processor = new FlowProcessor(appConfig.getStoragePath(), name, flowConfig);
                flows.put(name, processor);

                // Start it
                processor.startFlow();
            } else {
                logger.info("Flow {} is not enabled, skip it", name);
            }
        }

        // Set the related inbound flow
        for(FlowProcessor flowProcessor: flows.values()) {
            FlowConfig flowConfig = flowProcessor.getFlowConfig();
            if (FlowType.OUTBOUND.equals(flowConfig.getFlowType())) {
                String[] relatedInboundFlows = flowConfig.getRelatedInboundFlows();
                if (relatedInboundFlows != null) {
                    for (String item : relatedInboundFlows) {
                        FlowProcessor relatedInboundFlowProcessor = this.flows.get(item);

                        flowProcessor.addRelatedInboundFlow(relatedInboundFlowProcessor);
                    }
                }
            }
        }

        logger.info("App is ready, all enabled flows are started");
    }

    @Scheduled(fixedDelayString = "#{${ags-app.health-check-interval-seconds} * 1000}", initialDelayString = "#{${ags-app.health-check-interval-seconds} * 1000}")
    public void checkListenerHealth() {
        logger.info("");
        logger.info("=========Begin Health Check");

        for(String name: this.flows.keySet()) {
            FlowProcessor processor = this.flows.get(name);
            processor.checkHealth();
        }
        logger.info("=========End Health Check");
    }


    @PreDestroy
    public void shutdown() {
        logger.info("ApplicationScheduler shutting down");
        for(String name: this.flows.keySet()) {
            FlowProcessor processor = this.flows.get(name);
            processor.shutdown();
        }
    }
    public FlowProcessor findFlowProcessor(String name) {
        return this.flows.get(name);
    }

    public Map<String, FlowProcessor> getFlows() {
        return flows;
    }
}
