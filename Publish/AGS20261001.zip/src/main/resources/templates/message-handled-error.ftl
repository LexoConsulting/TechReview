AccountingGatewayService Support Notification - ERROR

Event Type: ${eventType}
Error Type: ${errorType}

Producer ID: ${producerId}
Region: ${region}
Correlation ID: ${correlationId}

Flow: ${flowName}
Destination: ${destinationName}

Exception Class: ${exceptionClass}
Exception Message: ${exceptionMessage}

Timestamp: ${timestamp}