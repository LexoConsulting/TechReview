AccountingGatewayService Support Notification - RECOVERED

Event Type: ${eventType}

Producer ID: ${producerId}
Region: ${region}
Correlation ID: ${correlationId}

Flow: ${flowName}
Destination: ${destinationName}

Timestamp: ${timestamp}
