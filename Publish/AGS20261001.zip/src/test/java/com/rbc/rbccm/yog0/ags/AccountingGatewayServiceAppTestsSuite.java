package com.rbc.rbccm.yog0.ags;

import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;

@Suite
@SuiteDisplayName("Main Test Suite")
@SelectPackages("com.rbc.rbccm.yog0.ags")
public class AccountingGatewayServiceAppTestsSuite {
}
