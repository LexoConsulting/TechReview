package com.rbc.rbccm.yog0.ags.simulator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// To run manually, instantiate with a configured ActiveMQConsumer and call start().
public class RimmsSimulator {

    private static final Logger logger = LoggerFactory.getLogger(RimmsSimulator.class);

//    private final ActiveMQConsumer activeMqConsumer;
//    private static final String REQUEST_QUEUE = "YOG0.8L00.AC.RECV_DEV";
//    private static final String RESPONSE_QUEUE = "8L00.YOG0.AC.REPLY_DEV";
//
//    public RimmsSimulator(ActiveMQConsumer activeMqConsumer) {
//        this.activeMqConsumer = activeMqConsumer;
//    }
//
//    // Creates a local channel configuration for ActiveMQ and listens for requests.
//    public void start() {
//        logger.info("Starting RimmsSimulator - listening on {}, sending to {}", REQUEST_QUEUE, RESPONSE_QUEUE);
//
//        activeMqConsumer.startListening("RimmsSimulator", REQUEST_QUEUE, this::handleRimmsRequest);
//    }
//
//    private void handleRimmsRequest(byte[] request) {
//        logger.info("RimmsSimulator received RIMMS request (length: {} bytes)", request != null ? request.length : 0);
//
//        I_Irisreq iIrisreq = new I_Irisreq();
//        iIrisreq.unmarshal(request, request.length);
//
//        logger.info("RimmsSimulator parsed request fields: source_sys_code={}, iris_hdr_sid={}, number of detail records={}",
//                iIrisreq.summary.source_sys_code, iIrisreq.summary.iris_hdr_sid, iIrisreq.details.size());
//
//        for (int i = 0; i < iIrisreq.details.size(); i++) {
//            var detail = iIrisreq.details.get(i);
//            logger.info("  detail[{}] - iris_dtl_sid: {}, cr_dr_id: {}, amt: {}, nbr: {}",
//                    i, detail.iris_dtl_sid, detail.cr_dr_id, detail.amt, detail.nbr);
//        }
//
//        O_Irisresp response = new O_Irisresp();
//        response.reply_pway_sys = "RIMMS";
//        response.reply_source_sys = iIrisreq.summary.source_sys_code;
//        response.reply_hdr_sid = iIrisreq.summary.iris_hdr_sid;
//        response.reply_ac_batch_id = "BATCH001";
//        String firstDetailSid = iIrisreq.details.isEmpty() ? "" : iIrisreq.details.get(0).iris_dtl_sid;
//        response.reply_dtl_sid = firstDetailSid;
//        response.reply_msg_status = "00";
//        response.reply_msg_nbr = "0000";
//        response.reply_msg_text = "SUCCESS";
//        response.reply_msg_text_1 = "Mock successful response";
//
//        byte[] responsePayload = response.marshal();
//
//        logger.info("RimmsSimulator sending mock response (length: {} bytes)", responsePayload != null ? responsePayload.length : 0);
//
//        activeMqConsumer.send(RESPONSE_QUEUE, responsePayload);
//    }
}
