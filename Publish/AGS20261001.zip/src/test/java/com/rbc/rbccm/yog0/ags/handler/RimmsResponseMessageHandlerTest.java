package com.rbc.rbccm.yog0.ags.handler;

import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryResponse;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.I_Irisresp;
import com.rbc.rbccm.yog0.ags.scheduler.FlowProcessor;
import com.rbc.rbccm.yog0.ags.transformer.RimmsResponseMessageTransformer;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RimmsResponseMessageHandlerTest {

    @Test
    void populateRequest_shouldUnmarshalMessageToResponseObject() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(RimmsResponseMessageTransformer.class))
                    .thenReturn(new RimmsResponseMessageTransformer());

            RimmsResponseMessageHandler handler = new RimmsResponseMessageHandler();
            byte[] payload = "RIM|IPY|0000000001|BATCH001|0000000002|0|1|SUCCESS|OK".getBytes();

            try {
                I_Irisresp response = handler.populateRequest(payload);

                assertNotNull(response);
                assertEquals("RIM", response.reply_pway_sys);
                assertEquals("IPY", response.reply_source_sys);
                assertEquals("0000000001", response.reply_hdr_sid);
                assertEquals("0", response.reply_msg_status);
                assertEquals("1", response.reply_msg_nbr);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Test
    void buildMessageKey_shouldStripLeadingZerosAndLookupHeaders() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(RimmsResponseMessageTransformer.class))
                    .thenReturn(new RimmsResponseMessageTransformer());

            RimmsResponseMessageHandler handler = new RimmsResponseMessageHandler();
            handler.flowProcessor = mock(FlowProcessor.class);
            I_Irisresp response = new I_Irisresp();
            response.reply_source_sys = "IPY";
            response.reply_hdr_sid = "0000000001";

            Map<String, String> inboundHeaders = new HashMap<>();
            inboundHeaders.put("correlationId", "abc-123");
            when(handler.flowProcessor.findAndRemoveRelatedInboundFlowMessageHeaders("IPY-1")).thenReturn(inboundHeaders);

            Map<String, String> headers = new HashMap<>();
            String messageKey = handler.buildMessageKey(response, headers);

            assertEquals("IPY-1", messageKey);
            assertEquals("abc-123", headers.get("correlationId"));
        }
    }

    @Test
    void transformRequest_shouldMapRimmsResponseToAccountingEntryResponse() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(RimmsResponseMessageTransformer.class))
                    .thenReturn(new RimmsResponseMessageTransformer());

            RimmsResponseMessageHandler handler = new RimmsResponseMessageHandler();
            I_Irisresp response = new I_Irisresp();
            response.reply_pway_sys = "RIM";
            response.reply_source_sys = "IPY";
            response.reply_hdr_sid = "0000000001";
            response.reply_ac_batch_id = "BATCH001";
            response.reply_dtl_sid = "0000000002";
            response.reply_msg_status = "0";
            response.reply_msg_nbr = "1";
            response.reply_msg_text = "SUCCESS";
            response.reply_msg_text_1 = " OK";

            AccountingEntryResponse dto = handler.transformRequest(response);

            assertNotNull(dto);
            assertEquals("RIM", dto.pathwaySystemCode());
            assertEquals("IPY", dto.sourceSystemCode());
            assertEquals("0000000001", dto.sid());
            assertEquals("BATCH001", dto.ac());
            assertEquals("0000000002", dto.detailSid());
            assertEquals("0001", dto.msgCode());
            assertEquals("SUCCESS OK", dto.msgText());
        }
    }

    @Test
    void sendToDestinationChannel_shouldSendJsonWithPartition() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(RimmsResponseMessageTransformer.class))
                    .thenReturn(new RimmsResponseMessageTransformer());

            RimmsResponseMessageHandler handler = new RimmsResponseMessageHandler();
            AbstractJmsProducer producer = mock(AbstractJmsProducer.class);
            ChannelConfig channelConfig = new ChannelConfig();
            channelConfig.setProducerPartitions(Map.of("IPY", 3));

            handler.destChannelConfig = channelConfig;
            handler.destChannelProducer = producer;
            Map<String, String> headers = Map.of("traceId", "xyz");
            AccountingEntryResponse dto = new AccountingEntryResponse("RIM", "IPY", "0000000001", "BATCH001", "0000000002", "0001", "SUCCESS OK");

            handler.sendToDestinationChannel(dto, "IPY-1", headers);

            verify(producer).send(eq("IPY-1"), anyString(), eq(3), eq(headers));
        }
    }

    private AccountingEntryResponse createAccountingEntryResponse() {
        return new AccountingEntryResponse("RIM", "IPY", "9999999001",
                "9999999001", "BATCH001", "SUCCESS", "Mock Success");
    }
}
