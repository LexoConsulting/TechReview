package com.rbc.rbccm.yog0.ags.handler;

import com.fasterxml.jackson.core.JacksonException;
import com.rbc.rbccm.yog0.ags.adapter.AbstractJmsProducer;
import com.rbc.rbccm.yog0.ags.config.channel.ChannelConfig;
import com.rbc.rbccm.yog0.ags.handler.dto.accountingEntry.AccountingEntryRequest;
import com.rbc.rbccm.yog0.ags.handler.dto.rimms.O_Irisreq;
import com.rbc.rbccm.yog0.ags.model.AccountingEntry;
import com.rbc.rbccm.yog0.ags.model.AccountingEntrySummary;
import com.rbc.rbccm.yog0.ags.transformer.AccountingEntryMessageTransformer;
import com.rbc.rbccm.yog0.ags.util.JsonUtil;
import com.rbc.rbccm.yog0.ags.util.SpringContextUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AccountingEntryRequestMessageHandlerTest {

    @Test
    void populateRequest_shouldParseJsonIntoAccountingEntryRequest() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(AccountingEntryMessageTransformer.class))
                    .thenReturn(new AccountingEntryMessageTransformer());

            AccountingEntryRequestMessageHandler handler = new AccountingEntryRequestMessageHandler();
            String json = JsonUtil.toJson(createAccountingEntryRequest());

            try {
                AccountingEntryRequest request = handler.populateRequest(json);

                assertNotNull(request);
                assertEquals("IPY", request.summary().sourceSystemCode());
                assertEquals("0000000001", request.summary().sid());
                assertEquals(2, request.details().size());
            } catch (JacksonException e) {
                fail("Failed to populate request", e);
            }
        }
    }

    @Test
    void buildMessageKey_shouldStripLeadingZerosFromSid() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(AccountingEntryMessageTransformer.class))
                    .thenReturn(new AccountingEntryMessageTransformer());

            AccountingEntryRequestMessageHandler handler = new AccountingEntryRequestMessageHandler();

            String messageKey = handler.buildMessageKey(createAccountingEntryRequest(), Map.of());

            assertEquals("IPY-1", messageKey);
        }
    }

    @Test
    void transformRequest_shouldConvertRequestToIrisObject() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(AccountingEntryMessageTransformer.class))
                    .thenReturn(new AccountingEntryMessageTransformer());

            AccountingEntryRequestMessageHandler handler = new AccountingEntryRequestMessageHandler();
            AccountingEntryRequest request = createAccountingEntryRequest();

            O_Irisreq irisRequest = handler.transformRequest(request);

            assertNotNull(irisRequest);
            assertNotNull(irisRequest.summary);
            assertEquals("IPY", irisRequest.summary.source_sys_code);
            assertEquals("0000000001", irisRequest.summary.iris_hdr_sid);
            assertEquals(2, irisRequest.details.size());
        }
    }

    @Test
    void sendToDestinationChannel_shouldMarshalAndSendPayload() {
        try (MockedStatic<SpringContextUtil> springContextUtil = mockStatic(SpringContextUtil.class)) {
            springContextUtil.when(() -> SpringContextUtil.getBean(AccountingEntryMessageTransformer.class))
                    .thenReturn(new AccountingEntryMessageTransformer());

            AccountingEntryRequestMessageHandler handler = new AccountingEntryRequestMessageHandler();
            AbstractJmsProducer producer = mock(AbstractJmsProducer.class);
            ChannelConfig channelConfig = new ChannelConfig();
            channelConfig.setTopic("ris.outbound.topic");

            when(producer.getChannelConfig()).thenReturn(channelConfig);
            when(producer.getFlowName()).thenReturn("test-flow");

            handler.destChannelProducer = producer;

            O_Irisreq request = handler.transformRequest(createAccountingEntryRequest());
            Map<String, String> headers = Map.of("traceId", "abc-123");

            handler.sendToDestinationChannel(request, "IPY-1", headers);

            verify(producer).send(eq("IPY-1"), any(byte[].class), isNull(), eq(headers));
        }
    }

    private AccountingEntryRequest createAccountingEntryRequest() {
        AccountingEntrySummary summary = new AccountingEntrySummary("IPY", "0000000001",
                "2026", "06", "03", "19", "00", "00",
                1, 1, new BigDecimal(1000), new BigDecimal(1000),
                "Sample accounting batch", "");

        List<AccountingEntry> details = new ArrayList<>();
        details.add(new AccountingEntry("2026", "06", "03", "0000000001", "CR", "1234567890", "001", "CAD", "01", "001", new BigDecimal(1000), "Sample credit record"));
        details.add(new AccountingEntry("2026", "06", "03", "0000000002", "DR", "0987654321", "001", "CAD", "01", "001", new BigDecimal(1000), "Sample debit record"));

        return new AccountingEntryRequest(summary, details);
    }
}
