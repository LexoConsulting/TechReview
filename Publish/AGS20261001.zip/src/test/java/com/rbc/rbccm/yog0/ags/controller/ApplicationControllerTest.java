package com.rbc.rbccm.yog0.ags.controller;

public class ApplicationControllerTest {
}
