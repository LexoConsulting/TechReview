package com.rbc.rbccm.yog0.ags.service.email;

import freemarker.template.Configuration;
import freemarker.template.Template;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmailServiceTest {

    @Mock
    private JavaMailSender javaMailSender;

    @Mock
    private Configuration freemarkerConfig;

    @Mock
    private MimeMessage mimeMessage;

    @Mock
    private Template template;

    private EmailService emailService;

    @BeforeEach
    void setUp() {
        lenient().when(javaMailSender.createMimeMessage()).thenReturn(mimeMessage);
        emailService = new EmailService(javaMailSender, freemarkerConfig);
    }

    @Test
    void testInit_ParsesCommaSeparatedEmails() {
        emailService.setTos("to1@example.com, to2@example.com, to3@example.com");
        emailService.setCcs("cc1@example.com,cc2@example.com");
        emailService.setBccs("bcc1@example.com");

        emailService.init();

        assertEquals(3, emailService.toList.size());
        assertEquals("to1@example.com", emailService.toList.get(0));
        assertEquals("to2@example.com", emailService.toList.get(1));
        assertEquals("to3@example.com", emailService.toList.get(2));

        assertEquals(2, emailService.ccList.size());
        assertEquals("cc1@example.com", emailService.ccList.get(0));
        assertEquals("cc2@example.com", emailService.ccList.get(1));

        assertEquals(1, emailService.bccList.size());
        assertEquals("bcc1@example.com", emailService.bccList.get(0));
    }

    @Test
    void testInit_HandlesEmptyStrings() {
        emailService.setTos("");
        emailService.setCcs(null);
        emailService.setBccs("  ");

        emailService.init();

        assertTrue(emailService.toList.isEmpty());
        assertTrue(emailService.ccList.isEmpty());
        assertTrue(emailService.bccList.isEmpty());
    }

    @Test
    void testSend_WhenDisabled_SkipsSending() {
        emailService.setEnabled(false);
        Email email = new Email();
        email.setSubject("Test Subject");

        emailService.send(email, new HashMap<>());

        verify(javaMailSender, never()).send(any(MimeMessage.class));
    }

    @Test
    void testSend_WhenEnabled_SendsEmail() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("mike@lexoconsulting.com");
        emailService.setTos("mikeyuan2008@google.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");

        emailService.send(email, new HashMap<>());

        verify(javaMailSender).send(any(MimeMessage.class));
    }

    @Test
    void testSend_UsesDefaultRecipientsWhenNotProvided() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("default-to@example.com");
        emailService.setCcs("default-cc@example.com");
        emailService.setBccs("default-bcc@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");

        emailService.send(email, new HashMap<>());

        ArgumentCaptor<MimeMessage> messageCaptor = ArgumentCaptor.forClass(MimeMessage.class);
        verify(javaMailSender).send(messageCaptor.capture());

        MimeMessage capturedMessage = messageCaptor.getValue();
        MimeMessageHelper helper = new MimeMessageHelper(capturedMessage);
        assertEquals("default-to@example.com", helper.getMimeMessage().getRecipients(jakarta.mail.Message.RecipientType.TO)[0].toString());
    }

    @Test
    void testSend_UsesEmailSpecificRecipientsWhenProvided() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("default-to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");
        email.setTos(List.of("specific-to@example.com"));
        email.setCcs(List.of("specific-cc@example.com"));

        emailService.send(email, new HashMap<>());

        verify(javaMailSender).send(any(MimeMessage.class));
    }

    @Test
    void testSend_WithAttachments() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");
        EmailAttachment attachment = new EmailAttachment();
        attachment.setFileName("test.txt");
        attachment.setContent("test content".getBytes());
        attachment.setContentType("text/plain");
        email.setAttachments(List.of(attachment));

        emailService.send(email, new HashMap<>());

        verify(javaMailSender).send(any(MimeMessage.class));
    }

    @Test
    void testSend_ThrowsExceptionWhenSendFails() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");

        doThrow(new RuntimeException("SMTP Error")).when(javaMailSender).send(any(MimeMessage.class));

        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            emailService.send(email, new HashMap<>());
        });

        assertEquals("Failed to send email", exception.getMessage());
    }

    @Test
    void testRenderSubject_WithTemplate() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        when(freemarkerConfig.getTemplate(anyString())).thenReturn(template);

        Email email = new Email();
        email.setSubjectTemplate("Hello ${name}");
        email.setContent("Test Content");

        Map<String, Object> data = new HashMap<>();
        data.put("name", "World");

        emailService.send(email, data);

        verify(javaMailSender).send(any(MimeMessage.class));
    }

    @Test
    void testRenderContent_WithTemplate() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        when(freemarkerConfig.getTemplate("test-template.ftl")).thenReturn(template);

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContentTemplate("test-template.ftl");

        Map<String, Object> data = new HashMap<>();
        data.put("key", "value");

        emailService.send(email, data);

        verify(freemarkerConfig).getTemplate("test-template.ftl");
    }

    @Test
    void testRenderContent_WithoutTemplate() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Static Content");

        emailService.send(email, new HashMap<>());

        verify(freemarkerConfig, never()).getTemplate(anyString());
    }

    @Test
    void testIsEnabled() {
        emailService.setEnabled(true);
        assertTrue(emailService.isEnabled());

        emailService.setEnabled(false);
        assertFalse(emailService.isEnabled());
    }

    @Test
    void testSend_WithNullData() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");

        emailService.send(email, null);

        verify(javaMailSender).send(any(MimeMessage.class));
    }

    @Test
    void testSend_WithEmptyData() throws Exception {
        emailService.setEnabled(true);
        emailService.setFrom("default@example.com");
        emailService.setTos("to@example.com");
        emailService.init();

        Email email = new Email();
        email.setSubject("Test Subject");
        email.setContent("Test Content");

        emailService.send(email, Collections.emptyMap());

        verify(javaMailSender).send(any(MimeMessage.class));
    }
}
