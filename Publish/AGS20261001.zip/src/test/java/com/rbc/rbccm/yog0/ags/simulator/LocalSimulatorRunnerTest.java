package com.rbc.rbccm.yog0.ags.simulator;

import com.rbc.rbccm.yog0.ags.adapter.activemq.ActiveMQConsumer;
import com.rbc.rbccm.yog0.ags.adapter.kafka.KafkaConsumer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LocalSimulatorRunnerTest {
    @Autowired
    private KafkaConsumer kafkaAdapter;

    @Autowired
    private ActiveMQConsumer activeMqAdapter;
//
//    @Test
//    void runEndToEndSimulatorFlow() throws Exception {
//        RimmsSimulator rimmsSimulator = new RimmsSimulator(activeMqAdapter);
//        AccountingSimulator accountingSimulator = new AccountingSimulator(kafkaAdapter);
//
//        rimmsSimulator.start();
//        accountingSimulator.start();
//
//        Thread.sleep(30_000);
//    }
}
