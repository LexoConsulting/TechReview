package com.rbc.rbccm.yog0.ags.simulator;

import com.rbc.rbccm.yog0.ags.adapter.kafka.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

// To run manually, instantiate with a configured KafkaConsumer and call start().

public class AccountingSimulator {
//
//    private static final Logger logger = LoggerFactory.getLogger(AccountingSimulator.class);
//
//    private final KafkaConsumer kafkaAdapter;
//    private static final String REQUEST_TOPIC = "yog0-d-accountingentryreq";
//    private static final String RESPONSE_TOPIC = "yog0-d-accountingentryresp";
//    private static final String GROUP_ID = "accounting-simulator-cg";
//
//    public AccountingSimulator(KafkaConsumer kafkaAdapter) {
//        this.kafkaAdapter = kafkaAdapter;
//    }
//
//    // Creates a local channel configuration for Kafka and sends a sample request.
//    public void start() {
//        logger.info("Starting AccountingSimulator - sending to {}, listening on {}", REQUEST_TOPIC, RESPONSE_TOPIC);
//
//        kafkaAdapter.startListeningWithHeadersAndAck("AccountingSimulator", RESPONSE_TOPIC, GROUP_ID, (body, headers, acknowledgment) -> {
//            handleAccountingResponse(body);
//            acknowledgment.acknowledge();
//        });
//
//        logger.info("AccountingSimulator waiting 5 seconds for Kafka listener partition assignment...");
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//            logger.warn("AccountingSimulator delay interrupted", e);
//        }
//        logger.info("AccountingSimulator delay complete, sending sample request");
//
//        sendSampleAccountingRequest("IPY", "TORONTO");
//        sendSampleAccountingRequest("RIB", "TORONTO");
//    }
//
//    private void sendSampleAccountingRequest(String sourceSystemCode, String region) {
//        String sampleRequest = createSampleAccountingRequest(sourceSystemCode);
//        Map<String, String> headers = createHeaders(sourceSystemCode, region);
//
//        logger.info("AccountingSimulator sending sample accounting request for sourceSystemCode={}, region={}: {}", sourceSystemCode, region, sampleRequest);
//        logger.info("AccountingSimulator sending headers: {}", headers);
//
//        kafkaAdapter.sendWithHeaders(REQUEST_TOPIC, sampleRequest, headers);
//    }
//
//    private void handleAccountingResponse(String response) {
//        logger.info("AccountingSimulator received accounting response: {}", response);
//    }
//
//    private String createSampleAccountingRequest(String sourceSystemCode) {
//        return "{"
//                + "\"summary\":{"
//                + "\"sourceSystemCode\":\"" + sourceSystemCode + "\","
//                + "\"sid\":\"0000000001\","
//                + "\"year\":\"2026\","
//                + "\"month\":\"06\","
//                + "\"day\":\"03\","
//                + "\"hour\":\"19\","
//                + "\"minute\":\"00\","
//                + "\"second\":\"00\","
//                + "\"creditCount\":1,"
//                + "\"debitCount\":1,"
//                + "\"creditAmount\":\"1000.00\","
//                + "\"debitAmount\":\"1000.00\","
//                + "\"description\":\"Sample accounting batch\","
//                + "\"reversal\":\"\""
//                + "},"
//                + "\"details\":["
//                + "{"
//                + "\"year\":\"2026\","
//                + "\"month\":\"06\","
//                + "\"day\":\"03\","
//                + "\"sid\":\"0000000001\","
//                + "\"payDirection\":\"CR\","
//                + "\"account\":\"1234567890\","
//                + "\"type\":\"001\","
//                + "\"currency\":\"CAD\","
//                + "\"classCode\":\"01\","
//                + "\"subBranch\":\"001\","
//                + "\"amount\":\"1000.00\","
//                + "\"transactionId\":\"Sample credit record\""
//                + "},"
//                + "{"
//                + "\"year\":\"2026\","
//                + "\"month\":\"06\","
//                + "\"day\":\"03\","
//                + "\"sid\":\"0000000002\","
//                + "\"payDirection\":\"DR\","
//                + "\"account\":\"0987654321\","
//                + "\"type\":\"001\","
//                + "\"currency\":\"CAD\","
//                + "\"classCode\":\"01\","
//                + "\"subBranch\":\"001\","
//                + "\"amount\":\"1000.00\","
//                + "\"transactionId\":\"Sample debit record\""
//                + "}"
//                + "]}";
//    }
//
//    private Map<String, String> createHeaders(String producerId, String region) {
//        Map<String, String> headers = new HashMap<>();
//        headers.put("producerId", producerId);
//        headers.put("region", region);
//        headers.put("correlationId", UUID.randomUUID().toString());
//        headers.put("timestamp", Instant.now().toString());
//        headers.put("schemaVersion", "1.0");
//        return headers;
//    }
}
